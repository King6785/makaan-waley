<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-W54PTZK');</script>
<!-- End Google Tag Manager -->
<!-- Google tag (gtag.js) — GA4 from wehouse.in -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-2HPW0KC1F0"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-2HPW0KC1F0');
</script>
<!-- Start of HubSpot Embed Code -->
<script id="hs-script-loader" async defer src="https://js.hs-scripts.com/20348301.js"></script>
<!-- End of HubSpot Embed Code -->

    <title>Residential Home Construction | &#x20B9;1,749/sft | WeHouse</title>
    <meta name="description" content="Your home, built on time. Priced exactly as quoted. From &#x20B9;1,749/sft &#x2014; architecture, structure, MEP, finishing, and e-monitoring. Fixed price. No hidden charges." />
    <meta name="p:domain_verify" content="a886b5fbe51dffb36a550c328b6cb5cf" />
    <link rel="canonical" href="https://www.wehouse.in/service/residential-construction" />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="WeHouse" />
    <meta property="og:title" content="Residential Home Construction | &#x20B9;1,749/sft | WeHouse" />
    <meta property="og:description" content="Your home, built on time. Priced exactly as quoted. From &#x20B9;1,749/sft &#x2014; architecture, structure, MEP, finishing, and e-monitoring. Fixed price. No hidden charges." />
    <meta property="og:url" content="https://www.wehouse.in/service/residential-construction" />
    <meta property="og:image" content="https://www.wehouse.in/images/wehouse-og.jpg" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="Residential Home Construction | &#x20B9;1,749/sft | WeHouse" />
    <meta name="twitter:description" content="Your home, built on time. Priced exactly as quoted. From &#x20B9;1,749/sft &#x2014; architecture, structure, MEP, finishing, and e-monitoring. Fixed price. No hidden charges." />
    <meta name="twitter:image" content="https://www.wehouse.in/images/wehouse-og.jpg" />
    <link rel="icon" type="image/svg+xml" href="/images/wehouse-icon.svg?v=MDlcJpVUQi12twFFIs4GxS-Kkls0puoi1-b_3boz7TA" />
    
    <!-- Preconnect to external domains -->
    <link rel="preconnect" href="https://www.googletagmanager.com">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
    <link rel="preconnect" href="https://unpkg.com" crossorigin>
    <link rel="dns-prefetch" href="https://www.googletagmanager.com">
    <link rel="dns-prefetch" href="https://cdnjs.cloudflare.com">
    <link rel="dns-prefetch" href="https://unpkg.com">
    
    <!-- Preload critical resources -->
    <link rel="preload" href="/fonts/Satoshi-Variable.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="/css/site.css?v=DLqZOEuko_-hdN2ivZISYjAD6kN4K1JMQdaqtcHVusE" as="style">
    
    <!-- Styles (fonts are self-hosted in CSS) -->
    <link rel="stylesheet" href="/css/site.css?v=DLqZOEuko_-hdN2ivZISYjAD6kN4K1JMQdaqtcHVusE" />
    
</head>
<body class="font-sans text-gray-600 antialiased bg-gray-50 relative overflow-x-hidden">
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W54PTZK" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    <a href="#main-content" class="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[300] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-dark focus:shadow-lg">Skip to main content</a>
    <header id="site-header" class="fixed top-0 left-0 right-0 z-50 bg-transparent transition-all duration-300 ease-out">
        <nav class="mx-auto flex max-w-[90rem] items-center justify-between gap-3 px-4 py-4 sm:gap-4 sm:px-6 lg:px-8">
            <div class="flex min-w-0 items-center">
                <a href="/" class="relative flex h-10 shrink-0 items-center gap-2">
                    <img id="header-logo" src="/images/wehouse-logo.svg" alt="WeHouse" class="block h-10 w-auto transition-opacity duration-300" fetchpriority="high" />
                    <img id="header-logo-white" src="/images/wehouse-logo-whiteorange.svg" alt="WeHouse" class="absolute left-0 top-1/2 h-10 w-auto -translate-y-1/2 opacity-0 transition-opacity duration-300" />
                </a>
            </div>
            <div id="nav-desktop" class="hidden items-center gap-5 lg:flex lg:gap-6 xl:gap-7">
                <div id="nav-city-wrap" class="relative flex h-10 shrink-0 items-center">
                    <select id="nav-city" name="city" class="sr-only" tabindex="-1" aria-hidden="true">
                        <option value="">City</option>
                            <option value="Amaravati">Amaravati</option>
    <option value="Hyderabad">Hyderabad</option>
    <option value="Ahmedabad">Ahmedabad</option>
    <option value="Chandigarh">Chandigarh</option>
    <option value="Chennai">Chennai</option>
    <option value="Bengaluru">Bengaluru</option>
    <option value="Jaipur">Jaipur</option>
    <option value="Pune">Pune</option>
    <option value="Lucknow">Lucknow</option>
    <option value="Vijayawada">Vijayawada</option>
<option value="Other">Other</option>

                    </select>
                    <button type="button" id="nav-city-trigger" class="inline-flex h-full max-w-[7.25rem] items-center gap-1 wh-label-sm leading-none text-dark transition-colors hover:text-amber-500 sm:max-w-[9rem]" aria-haspopup="listbox" aria-expanded="false" aria-controls="nav-city-menu">
                        <svg class="h-3.5 w-3.5 shrink-0 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        <span id="nav-city-label" class="truncate">City</span>
                        <svg class="h-3.5 w-3.5 shrink-0 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <div id="nav-city-menu" class="nav-city-menu hidden absolute left-0 top-full z-[60] mt-2 w-44 max-h-64 overflow-y-auto rounded-xl border border-gray-200 bg-white p-1.5 shadow-xl" role="listbox" aria-label="Select your city">
                        <button type="button" role="option" data-nav-city-value="" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Select city</button>
    <button type="button" role="option" data-nav-city-value="Amaravati" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Amaravati</button>
    <button type="button" role="option" data-nav-city-value="Hyderabad" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Hyderabad</button>
    <button type="button" role="option" data-nav-city-value="Ahmedabad" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Ahmedabad</button>
    <button type="button" role="option" data-nav-city-value="Chandigarh" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Chandigarh</button>
    <button type="button" role="option" data-nav-city-value="Chennai" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Chennai</button>
    <button type="button" role="option" data-nav-city-value="Bengaluru" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Bengaluru</button>
    <button type="button" role="option" data-nav-city-value="Jaipur" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Jaipur</button>
    <button type="button" role="option" data-nav-city-value="Pune" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Pune</button>
    <button type="button" role="option" data-nav-city-value="Lucknow" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Lucknow</button>
    <button type="button" role="option" data-nav-city-value="Vijayawada" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Vijayawada</button>
<button type="button" role="option" data-nav-city-value="Other" class="nav-city-option block w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Other</button>

                    </div>
                </div>
                <a href="/" id="nav-desktop-home" class="wh-label-sm text-dark hover:text-amber-500 transition-colors">Home</a>
                <div class="relative group" data-nav-dropdown>
                    <button type="button" class="inline-flex items-center gap-1 wh-label-sm text-dark hover:text-amber-500 transition-colors cursor-pointer" aria-haspopup="true" aria-expanded="false" aria-controls="nav-services-menu">
                        Services
                        <svg class="h-4 w-4 transition-transform group-data-[open]:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div id="nav-services-menu" class="invisible absolute left-0 top-full z-50 w-72 rounded-xl border border-gray-200 bg-white p-2 opacity-0 shadow-xl transition-all duration-150 pointer-events-none group-hover:visible group-hover:opacity-100 group-hover:pointer-events-auto group-focus-within:visible group-focus-within:opacity-100 group-focus-within:pointer-events-auto group-data-[open]:visible group-data-[open]:opacity-100 group-data-[open]:pointer-events-auto">
                        <a href="/service/residential-construction" class="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">
                            <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-500">
                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none"><path d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.55 5.45 21 6 21H9M19 10L21 12M19 10V20C19 20.55 18.55 21 18 21H15M9 21V15H15V21M9 21H15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            Home Construction
                        </a>
                        <a href="/service/commercial-construction" class="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">
                            <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-500">
                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none"><path d="M3 21H21M3 7H21M6 21V7M18 21V7M10 21V17H14V21M10 11H11M13 11H14M10 15H11M13 15H14M10 7V3H14V7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            Commercial Construction
                        </a>
                        <a href="/service/architecture-structural" class="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">
                            <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-500">
                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none"><path d="M2 20H22M4 20V10M20 20V10M12 4L4 10H20L12 4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 20V15C9 14.45 9.45 14 10 14H14C14.55 14 15 14.45 15 15V20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            Architecture &amp; Structure
                        </a>
                        <a href="/service/interior-designing" class="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">
                            <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-500">
                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none"><path d="M3 9L12 2L21 9V20C21 20.55 20.55 21 20 21H4C3.45 21 3 20.55 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 21V12H15V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            Interiors &amp; Smart Homes
                        </a>
                    </div>
                </div>
                <a href="/portfolio" class="wh-label-sm text-dark hover:text-amber-500 transition-colors">Projects</a>
                <a id="nav-packages-link" href="/packages" class="wh-label-sm text-dark hover:text-amber-500 transition-colors">Packages</a>
                <a href="/quality-assurance" class="wh-label-sm text-dark hover:text-amber-500 transition-colors">Quality Assurance</a>
                <div class="relative group" data-nav-dropdown>
                    <button type="button" class="inline-flex items-center gap-1 wh-label-sm text-dark hover:text-amber-500 transition-colors cursor-pointer" aria-haspopup="true" aria-expanded="false" aria-controls="nav-more-menu">
                        More
                        <svg class="h-4 w-4 transition-transform group-data-[open]:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div id="nav-more-menu" class="invisible absolute right-0 top-full z-50 w-56 rounded-xl border border-gray-200 bg-white p-2 opacity-0 shadow-xl transition-all duration-150 pointer-events-none group-hover:visible group-hover:opacity-100 group-hover:pointer-events-auto group-focus-within:visible group-focus-within:opacity-100 group-focus-within:pointer-events-auto group-data-[open]:visible group-data-[open]:opacity-100 group-data-[open]:pointer-events-auto">
                        <a href="/how-it-works" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">How it Works</a>
                        <a href="/faqs" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">FAQs</a>
                        <a href="/glossary" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Glossary</a>
                        <a href="/emonitoring" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">E-Monitoring</a>
                        <a href="/testimonials" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Testimonials</a>
                        <a href="/why-choose-us" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Why Choose Us</a>
                        <a href="/blog" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Blogs</a>
                        <a href="/media" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Media</a>
                        <a href="/become-a-professional" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Careers</a>
                        <a href="/company/about-us" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">About Us</a>
                        <a id="nav-cost-calculator-link" href="/planner" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Cost Calculator</a>
                        <a href="/contact-us" class="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600">Contact Us</a>
                    </div>
                </div>
                <button type="button" data-lead-popup-trigger data-lead-popup-title="Ready to build your dream home?" data-lead-popup-lede="Let's start with your needs" class="rounded-xl bg-amber-500 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-amber-600 transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/25">Let&apos;s Build</button>
            </div>
            <button id="nav-toggle" type="button" class="inline-flex shrink-0 touch-manipulation items-center justify-center rounded-md p-2 text-dark hover:bg-gray-100 lg:hidden" aria-label="Toggle menu" aria-controls="nav-mobile" aria-expanded="false">
                <svg id="nav-icon-open" class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <svg id="nav-icon-close" class="hidden h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </nav>
        <div id="nav-mobile" class="hidden border-t border-white/10 bg-dark lg:hidden max-h-[calc(100dvh-4.5rem)] overflow-y-auto">
            <div class="flex flex-col gap-1 px-4 py-4">
                <div id="nav-city-mobile-slot" class="px-1 py-1"></div>
                <a href="/" id="nav-mobile-home" class="rounded-lg px-3 py-2 wh-label-sm text-white/80 hover:text-amber-500 hover:bg-white/5 transition-colors">Home</a>
                <details name="mobile-nav" class="open:[&_summary_svg]:rotate-180">
                    <summary class="flex cursor-pointer list-none items-center justify-between rounded-lg px-3 py-2 wh-label-sm text-white/80 transition-colors hover:bg-white/5 hover:text-amber-500 [&::-webkit-details-marker]:hidden">
                        Services
                        <svg class="h-4 w-4 shrink-0 transition-transform duration-150" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
                    </summary>
                    <div class="mb-1 ml-2 flex flex-col gap-0.5 border-l border-white/10 pl-2">
                        <a href="/service/residential-construction" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Home Construction</a>
                        <a href="/service/commercial-construction" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Commercial Construction</a>
                        <a href="/service/architecture-structural" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Architecture &amp; Structure</a>
                        <a href="/service/interior-designing" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Interiors &amp; Smart Homes</a>
                    </div>
                </details>
                <a href="/portfolio" class="rounded-lg px-3 py-2 wh-label-sm text-white/80 hover:text-amber-500 hover:bg-white/5 transition-colors">Projects</a>
                <a id="nav-packages-link-mobile" href="/packages" class="rounded-lg px-3 py-2 wh-label-sm text-white/80 hover:text-amber-500 hover:bg-white/5 transition-colors">Packages</a>
                <a href="/quality-assurance" class="rounded-lg px-3 py-2 wh-label-sm text-white/80 hover:text-amber-500 hover:bg-white/5 transition-colors">Quality Assurance</a>
                <details name="mobile-nav" class="open:[&_summary_svg]:rotate-180">
                    <summary class="flex cursor-pointer list-none items-center justify-between rounded-lg px-3 py-2 wh-label-sm text-white/80 transition-colors hover:bg-white/5 hover:text-amber-500 [&::-webkit-details-marker]:hidden">
                        More
                        <svg class="h-4 w-4 shrink-0 transition-transform duration-150" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
                    </summary>
                    <div class="mb-1 ml-2 flex flex-col gap-0.5 border-l border-white/10 pl-2">
                        <a href="/how-it-works" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">How it Works</a>
                        <a href="/faqs" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">FAQs</a>
                        <a href="/glossary" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Glossary</a>
                        <a href="/emonitoring" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">E-Monitoring</a>
                        <a href="/testimonials" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Testimonials</a>
                        <a href="/why-choose-us" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Why Choose Us</a>
                        <a href="/blog" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Blogs</a>
                        <a href="/media" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Media</a>
                        <a href="/become-a-professional" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Careers</a>
                        <a href="/company/about-us" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">About Us</a>
                        <a id="nav-cost-calculator-link-mobile" href="/planner" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Cost Calculator</a>
                        <a href="/contact-us" class="rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-amber-500 transition-colors">Contact Us</a>
                    </div>
                </details>
                <button type="button" data-lead-popup-trigger data-lead-popup-title="Ready to build your dream home?" data-lead-popup-lede="Let's start with your needs" class="mt-2 rounded-xl bg-amber-500 px-3 py-2 text-center text-sm font-semibold text-white hover:bg-amber-600">Let&apos;s Build</button>
            </div>
        </div>
    </header>

    <main id="main-content">
        
<div>
    
<section class="relative overflow-hidden bg-white border-b border-gray-900/[0.08]">
    <img src="/images/header-bg-white.webp?v=kROUhUnmB5TZOhXJS_3cSJxgtmI7ZLciwsWZwUwvXfI" alt="" class="pointer-events-none absolute inset-0 h-full w-full object-cover object-center" loading="eager" decoding="async" aria-hidden="true" />

        <div class="pointer-events-none absolute inset-0 bg-[linear-gradient(90deg,rgba(255,255,255,0.72)_0%,rgba(255,255,255,0.28)_42%,rgba(255,255,255,0.06)_100%),radial-gradient(circle_at_15%_20%,rgba(249,115,22,0.08),transparent_52%)]" aria-hidden="true"></div>

    <div class="relative wh-container w-full pb-8 pt-24 sm:pb-10 sm:pt-28">
        <div class="max-w-3xl">
            <span class="wh-eyebrow-chip bg-orange-50 border-orange-200 text-amber-700">
Residential Home Construction · 
                    <span data-selected-city-name data-selected-city-fallback="Hyderabad">Hyderabad</span>
            </span>
            <h1 class="wh-heading-hero text-dark">Your home, built on time. Priced exactly as quoted.</h1>
            <p class="mt-3 wh-body-lg text-gray-600 max-w-xl">One fixed price. Architecture, structure, MEP, finishing, and e-monitoring &#x2014; all included. No hidden charges. No surprises. Ever.</p>

                <div class="mt-4 inline-flex flex-col rounded-2xl border border-amber-200 bg-white/80 px-5 py-3.5 shadow-sm backdrop-blur-sm"
                     data-city-starting-package
                     data-city-starting-package-map="{&quot;Amaravati&quot;:{&quot;amount&quot;:&quot;\u20B91,769&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;},&quot;Hyderabad&quot;:{&quot;amount&quot;:&quot;\u20B91,749&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;},&quot;Ahmedabad&quot;:{&quot;amount&quot;:&quot;\u20B91,789&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;},&quot;Chandigarh&quot;:{&quot;amount&quot;:&quot;\u20B91,839&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;},&quot;Chennai&quot;:{&quot;amount&quot;:&quot;\u20B91,829&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;},&quot;Bengaluru&quot;:{&quot;amount&quot;:&quot;\u20B91,869&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;},&quot;Jaipur&quot;:{&quot;amount&quot;:&quot;\u20B91,779&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;},&quot;Pune&quot;:{&quot;amount&quot;:&quot;\u20B91,809&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;},&quot;Lucknow&quot;:{&quot;amount&quot;:&quot;\u20B91,774&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;},&quot;Vijayawada&quot;:{&quot;amount&quot;:&quot;\u20B91,769&quot;,&quot;packageName&quot;:&quot;Economy Package&quot;}}">
                        <p class="wh-meta text-gray-500"
                           data-selected-city-package-name
                           data-selected-city-package-name-fallback="Economy Package">Economy Package</p>
                    <p class="flex items-baseline gap-2">
                        <span class="wh-price text-dark"
                              data-selected-city-price
                              data-selected-city-price-fallback="&#x20B9;1,749">&#x20B9;1,749</span>
                        <span class="wh-price-unit text-gray-500">/ sq.ft.</span>
                    </p>
                </div>

                <ul class="mt-4 flex flex-wrap gap-2">
                        <li class="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white/90 px-3 py-1.5 wh-label-sm text-gray-700">
                            <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                            ISI-certified materials
                        </li>
                        <li class="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white/90 px-3 py-1.5 wh-label-sm text-gray-700">
                            <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                            Live E-monitoring
                        </li>
                        <li class="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white/90 px-3 py-1.5 wh-label-sm text-gray-700">
                            <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                            Delay? We pay rent
                        </li>
                </ul>

            <div class="mt-6 flex flex-wrap gap-3">
                <a href="#" data-lead-popup-trigger class="wh-btn-primary wh-btn--lg">Get My Free Cost Estimate &#x2192;</a>
                <a href="#construction-process" class="wh-btn-secondary wh-btn--lg bg-white border-gray-200 text-dark hover:bg-orange-50 hover:border-orange-300 hover:text-amber-700">See 24 milestones &#x2193;</a>
            </div>
        </div>

    </div>
</section>


            <section class="bg-dark text-white py-7 border-b border-white/[0.08]" id="service-stats" aria-label="WeHouse at a glance">
        <div class="wh-container">
            <ul class="grid grid-cols-2 gap-x-4 gap-y-5 list-none m-0 p-0 lg:grid-cols-4 lg:gap-4">
                    <li class="text-center">
                        <p class="wh-stat-md text-orange-500">500&#x2B;</p>
                        <p class="mt-1 wh-meta uppercase tracking-widest text-white/65">Projects</p>
                    </li>
                    <li class="text-center">
                        <p class="wh-stat-md text-orange-500">25L&#x2B;</p>
                        <p class="mt-1 wh-meta uppercase tracking-widest text-white/65">Sq.ft. built</p>
                    </li>
                    <li class="text-center">
                        <p class="wh-stat-md text-orange-500">5000&#x2B;</p>
                        <p class="mt-1 wh-meta uppercase tracking-widest text-white/65">Workforce</p>
                    </li>
                    <li class="text-center">
                        <p class="wh-stat-md text-orange-500">4.9&#x2605;</p>
                        <p class="mt-1 wh-meta uppercase tracking-widest text-white/65">Rating</p>
                    </li>
            </ul>
        </div>
    </section>

            <section class="wh-section relative overflow-hidden bg-gray-50 border-y border-gray-900/[0.06]" id="service-emonitoring">
        <div class="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_18%,rgba(249,115,22,0.08),transparent_48%),radial-gradient(circle_at_90%_12%,rgba(245,158,11,0.07),transparent_42%)]" aria-hidden="true"></div>
        <div class="wh-container relative z-10">
            <div class="grid items-center gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-x-6">
                <div>
                    <div class="wh-section-head wh-section-head--start mb-6">
                        <span class="wh-eyebrow-chip">E-Monitoring Platform</span>
                        <h2 class="wh-heading-lg text-dark">Your phone is the site visit.</h2>
                            <p class="wh-section-head__lede text-left max-w-xl">Most people building a home are in the dark. WeHouse gives you 24/7 visibility &#x2014; live CCTV feeds, daily photo and video reports, material logs, cost tracker, workforce attendance &#x2014; all from your phone, from anywhere in the world.</p>
                    </div>

                        <div class="flex flex-wrap gap-3">
                            <a href="/emonitoring" class="wh-btn-primary">Explore E-Monitoring &#x2192;</a>
                        </div>

                    <div class="mt-6 grid grid-cols-2 gap-2.5 sm:grid-cols-2" role="list">
                            <span class="flex min-h-11 items-center justify-start rounded-xl border border-gray-900/[0.08] bg-white/90 px-3.5 py-2.5 text-left wh-label-sm font-bold text-dark leading-snug" role="listitem">Live CCTV Feeds</span>
                            <span class="flex min-h-11 items-center justify-start rounded-xl border border-gray-900/[0.08] bg-white/90 px-3.5 py-2.5 text-left wh-label-sm font-bold text-dark leading-snug" role="listitem">Daily Photos &amp; Videos</span>
                            <span class="flex min-h-11 items-center justify-start rounded-xl border border-gray-900/[0.08] bg-white/90 px-3.5 py-2.5 text-left wh-label-sm font-bold text-dark leading-snug" role="listitem">Timeline Tracking</span>
                            <span class="flex min-h-11 items-center justify-start rounded-xl border border-gray-900/[0.08] bg-white/90 px-3.5 py-2.5 text-left wh-label-sm font-bold text-dark leading-snug" role="listitem">Complete Material Report</span>
                            <span class="flex min-h-11 items-center justify-start rounded-xl border border-gray-900/[0.08] bg-white/90 px-3.5 py-2.5 text-left wh-label-sm font-bold text-dark leading-snug" role="listitem">Workforce Report</span>
                            <span class="flex min-h-11 items-center justify-start rounded-xl border border-gray-900/[0.08] bg-white/90 px-3.5 py-2.5 text-left wh-label-sm font-bold text-dark leading-snug" role="listitem">Cost Transparency</span>
                            <span class="flex min-h-11 items-center justify-start rounded-xl border border-gray-900/[0.08] bg-white/90 px-3.5 py-2.5 text-left wh-label-sm font-bold text-dark leading-snug" role="listitem">Smart Alerts</span>
                            <span class="flex min-h-11 items-center justify-start rounded-xl border border-gray-900/[0.08] bg-white/90 px-3.5 py-2.5 text-left wh-label-sm font-bold text-dark leading-snug" role="listitem">Access from Anywhere</span>
                    </div>
                </div>

                    <figure class="m-0 overflow-visible border-0 bg-transparent p-0 shadow-none">
                        <img src="/images/e-monitoring.webp?v=RviPyQ35Eba5_3PrXSiiiCSG7i_drp0ZZ_3DM_KjPDI" alt="WeHouse E-Monitoring dashboard" class="block h-auto w-full max-w-full object-contain" loading="lazy" decoding="async" />
                    </figure>
            </div>
        </div>
    </section>

            <section class="wh-section wh-section--compact wh-section--dark relative overflow-hidden" id="service-four-ts" aria-labelledby="service-four-ts-heading">
        <div class="wh-dark-dot-grid absolute inset-0 pointer-events-none" aria-hidden="true"></div>
        <div class="pointer-events-none absolute -top-32 -right-32 h-[420px] w-[420px] rounded-full bg-amber-500/5 blur-[100px]" aria-hidden="true"></div>

        <div class="wh-container relative z-10">
            <div class="mx-auto mb-6 max-w-3xl text-center">
                <span class="wh-eyebrow-chip">The 4 Ts</span>
                    <h2 id="service-four-ts-heading" class="wh-heading-md text-white">Embedded into every project from day one.</h2>
            </div>

            <ul class="m-0 grid list-none gap-4 p-0 sm:grid-cols-2 lg:grid-cols-4" role="list">
                    <li class="h-full" role="listitem">
                        <article class="wh-card wh-card--interactive group relative flex h-full flex-col overflow-hidden p-4 pt-5 text-left before:pointer-events-none before:absolute before:inset-x-0 before:top-0 before:h-0.5 before:bg-gradient-to-r before:from-transparent before:via-amber-500/80 before:to-transparent before:opacity-70 before:transition-opacity group-hover:before:opacity-100">
                            <div class="mb-2.5 flex items-center gap-2.5">
                                <span class="wh-icon-tile shrink-0 text-sm font-black tabular-nums" aria-hidden="true">1</span>
                                <h3 class="wh-heading-sm font-extrabold text-white">Transparency</h3>
                            </div>
                            <p class="text-sm leading-snug text-neutral-400">Every cost, material, decision &#x2014; visible.</p>
                        </article>
                    </li>
                    <li class="h-full" role="listitem">
                        <article class="wh-card wh-card--interactive group relative flex h-full flex-col overflow-hidden p-4 pt-5 text-left before:pointer-events-none before:absolute before:inset-x-0 before:top-0 before:h-0.5 before:bg-gradient-to-r before:from-transparent before:via-amber-500/80 before:to-transparent before:opacity-70 before:transition-opacity group-hover:before:opacity-100">
                            <div class="mb-2.5 flex items-center gap-2.5">
                                <span class="wh-icon-tile shrink-0 text-sm font-black tabular-nums" aria-hidden="true">2</span>
                                <h3 class="wh-heading-sm font-extrabold text-white">Time</h3>
                            </div>
                            <p class="text-sm leading-snug text-neutral-400">On-time or we pay rent.</p>
                        </article>
                    </li>
                    <li class="h-full" role="listitem">
                        <article class="wh-card wh-card--interactive group relative flex h-full flex-col overflow-hidden p-4 pt-5 text-left before:pointer-events-none before:absolute before:inset-x-0 before:top-0 before:h-0.5 before:bg-gradient-to-r before:from-transparent before:via-amber-500/80 before:to-transparent before:opacity-70 before:transition-opacity group-hover:before:opacity-100">
                            <div class="mb-2.5 flex items-center gap-2.5">
                                <span class="wh-icon-tile shrink-0 text-sm font-black tabular-nums" aria-hidden="true">3</span>
                                <h3 class="wh-heading-sm font-extrabold text-white">Tracking</h3>
                            </div>
                            <p class="text-sm leading-snug text-neutral-400">24 milestones, all live.</p>
                        </article>
                    </li>
                    <li class="h-full" role="listitem">
                        <article class="wh-card wh-card--interactive group relative flex h-full flex-col overflow-hidden p-4 pt-5 text-left before:pointer-events-none before:absolute before:inset-x-0 before:top-0 before:h-0.5 before:bg-gradient-to-r before:from-transparent before:via-amber-500/80 before:to-transparent before:opacity-70 before:transition-opacity group-hover:before:opacity-100">
                            <div class="mb-2.5 flex items-center gap-2.5">
                                <span class="wh-icon-tile shrink-0 text-sm font-black tabular-nums" aria-hidden="true">4</span>
                                <h3 class="wh-heading-sm font-extrabold text-white">Technology</h3>
                            </div>
                            <p class="text-sm leading-snug text-neutral-400">India&#x27;s No.1 tech platform.</p>
                        </article>
                    </li>
            </ul>
        </div>
    </section>

            <section id="construction-process" class="wh-section bg-white overflow-hidden">
        <div class="wh-container">
            <div class="wh-section-head">
                <span class="wh-eyebrow-chip">24-Milestone system</span>
                <h2 class="wh-heading-xl text-dark">From survey to handover — every step locked</h2>
                <div class="mt-6 flex flex-wrap justify-center gap-3">
                    <a href="#service-lead-form" class="wh-btn-primary">Start My Project →</a>
                    <a href="#service-portfolio" class="wh-btn-tertiary">See completed homes ↓</a>
                </div>
            </div>

            <div class="mt-8" data-milestone-tabs>
                <div class="flex gap-2 overflow-x-auto scroll-smooth snap-x snap-mandatory pb-1.5 [-ms-overflow-style:none] [scrollbar-width:none] md:grid md:grid-cols-6 md:overflow-visible [&::-webkit-scrollbar]:hidden" role="tablist" aria-label="Construction phases">
                        <button type="button"
                                class="min-w-[7.5rem] shrink-0 snap-start rounded-[0.85rem] border border-gray-200 bg-white px-3.5 py-2.5 text-left transition-colors hover:border-orange-300 md:min-w-0 md:w-full [&.is-active]:border-orange-300 [&.is-active]:bg-orange-50 is-active"
                                role="tab"
                                id="milestone-tab-0"
                                aria-selected="true"
                                aria-controls="milestone-panel-0"
                                data-milestone-tab="0">
                            <span class="block wh-meta font-extrabold uppercase tracking-widest text-amber-700">01-04</span>
                            <span class="mt-0.5 block wh-label-sm font-bold text-dark">Foundation</span>
                        </button>
                        <button type="button"
                                class="min-w-[7.5rem] shrink-0 snap-start rounded-[0.85rem] border border-gray-200 bg-white px-3.5 py-2.5 text-left transition-colors hover:border-orange-300 md:min-w-0 md:w-full [&.is-active]:border-orange-300 [&.is-active]:bg-orange-50"
                                role="tab"
                                id="milestone-tab-1"
                                aria-selected="false"
                                aria-controls="milestone-panel-1"
                                data-milestone-tab="1">
                            <span class="block wh-meta font-extrabold uppercase tracking-widest text-amber-700">05-08</span>
                            <span class="mt-0.5 block wh-label-sm font-bold text-dark">Structure</span>
                        </button>
                        <button type="button"
                                class="min-w-[7.5rem] shrink-0 snap-start rounded-[0.85rem] border border-gray-200 bg-white px-3.5 py-2.5 text-left transition-colors hover:border-orange-300 md:min-w-0 md:w-full [&.is-active]:border-orange-300 [&.is-active]:bg-orange-50"
                                role="tab"
                                id="milestone-tab-2"
                                aria-selected="false"
                                aria-controls="milestone-panel-2"
                                data-milestone-tab="2">
                            <span class="block wh-meta font-extrabold uppercase tracking-widest text-amber-700">09-12</span>
                            <span class="mt-0.5 block wh-label-sm font-bold text-dark">Walls &amp; MEP</span>
                        </button>
                        <button type="button"
                                class="min-w-[7.5rem] shrink-0 snap-start rounded-[0.85rem] border border-gray-200 bg-white px-3.5 py-2.5 text-left transition-colors hover:border-orange-300 md:min-w-0 md:w-full [&.is-active]:border-orange-300 [&.is-active]:bg-orange-50"
                                role="tab"
                                id="milestone-tab-3"
                                aria-selected="false"
                                aria-controls="milestone-panel-3"
                                data-milestone-tab="3">
                            <span class="block wh-meta font-extrabold uppercase tracking-widest text-amber-700">13-16</span>
                            <span class="mt-0.5 block wh-label-sm font-bold text-dark">MEP Fixtures</span>
                        </button>
                        <button type="button"
                                class="min-w-[7.5rem] shrink-0 snap-start rounded-[0.85rem] border border-gray-200 bg-white px-3.5 py-2.5 text-left transition-colors hover:border-orange-300 md:min-w-0 md:w-full [&.is-active]:border-orange-300 [&.is-active]:bg-orange-50"
                                role="tab"
                                id="milestone-tab-4"
                                aria-selected="false"
                                aria-controls="milestone-panel-4"
                                data-milestone-tab="4">
                            <span class="block wh-meta font-extrabold uppercase tracking-widest text-amber-700">17-20</span>
                            <span class="mt-0.5 block wh-label-sm font-bold text-dark">Finishing</span>
                        </button>
                        <button type="button"
                                class="min-w-[7.5rem] shrink-0 snap-start rounded-[0.85rem] border border-gray-200 bg-white px-3.5 py-2.5 text-left transition-colors hover:border-orange-300 md:min-w-0 md:w-full [&.is-active]:border-orange-300 [&.is-active]:bg-orange-50"
                                role="tab"
                                id="milestone-tab-5"
                                aria-selected="false"
                                aria-controls="milestone-panel-5"
                                data-milestone-tab="5">
                            <span class="block wh-meta font-extrabold uppercase tracking-widest text-amber-700">21-24</span>
                            <span class="mt-0.5 block wh-label-sm font-bold text-dark">Handover</span>
                        </button>
                </div>

                    <div class="mt-5 rounded-2xl border border-gray-200 bg-gray-50 p-5 md:p-6 is-active"
                         role="tabpanel"
                         id="milestone-panel-0"
                         aria-labelledby="milestone-tab-0"
                         data-milestone-panel="0"
                         >
                        <div class="mb-4 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 border-b border-gray-200 pb-3.5">
                            <h3 class="wh-heading-md text-dark">Foundation</h3>
                            <p class="wh-label-sm font-semibold text-amber-700">Milestones 1&#x2013;4</p>
                        </div>

                        <ol class="grid list-none gap-3.5 p-0 m-0 md:grid-cols-2 md:gap-4">
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">01</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Survey &amp; Soil Test</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Soil &amp; geotechnical report, layout marking, site survey. Foundation depth: 6&#x27;6&quot; standard.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">02</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Legal &amp; Permissions</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Plan approval, building permits, layout sanctioning &#x2014; WeHouse manages all.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">03</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Excavation (JCB/Workforce)</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Pit excavation, PCC layer. Anti-termite treatment (ATT).</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">04</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Sub-Structure</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Footings (as per structural drawings), sump RCC 6000L, plinth height 2ft. River sand for brickwork and plaster.</p>
                                    </div>
                                </li>
                        </ol>

                        <div class="mt-5 rounded-[0.85rem] border border-orange-200 bg-orange-50 px-4 py-4">
                            <p class="mb-2.5 wh-meta font-extrabold uppercase tracking-widest text-amber-700">What you receive</p>
                            <ul class="grid list-none gap-1.5 p-0 m-0 md:grid-cols-2">
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Soil &amp; geotechnical report &#x2014; signed copy</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Foundation inspection certificate &#x2B; depth photos</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Material batch delivery log (cement/steel)</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Milestone-04 sign-off before structure begins</span>
                                    </li>
                            </ul>
                        </div>
                        <p class="mt-4 wh-label-sm text-gray-500">
                            These are high-level specifications. For in-depth specs, refer to Annexure 2.
                            <a href="#service-lead-form" class="font-semibold text-amber-700 underline underline-offset-2 hover:text-amber-800">Contact us today</a>
                            for details.
                        </p>
                    </div>
                    <div class="mt-5 rounded-2xl border border-gray-200 bg-gray-50 p-5 md:p-6"
                         role="tabpanel"
                         id="milestone-panel-1"
                         aria-labelledby="milestone-tab-1"
                         data-milestone-panel="1"
                         hidden>
                        <div class="mb-4 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 border-b border-gray-200 pb-3.5">
                            <h3 class="wh-heading-md text-dark">Structure</h3>
                            <p class="wh-label-sm font-semibold text-amber-700">Milestones 5&#x2013;8</p>
                        </div>

                        <ol class="grid list-none gap-3.5 p-0 m-0 md:grid-cols-2 md:gap-4">
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">05</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Super-Structure</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">RMC M20, columns M20 as per design, beams &amp; slabs. ISI-certified cement. Ceiling height: 10&#x27;6&quot; FFL to FFL.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">06</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Brickwork</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Red Brick 9&quot; (external) and 4.5&quot; (internal). River sand mortar. Plumb and level verified per floor.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">07</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Plastering</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">River sand plaster. Internal and external &#x2014; surface quality and thickness inspected before next stage.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">08</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Elevation</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">1% of project cost allocated to elevation design. External waterproofing with verified systems. Weatherproof exterior paint.</p>
                                    </div>
                                </li>
                        </ol>

                        <div class="mt-5 rounded-[0.85rem] border border-orange-200 bg-orange-50 px-4 py-4">
                            <p class="mb-2.5 wh-meta font-extrabold uppercase tracking-widest text-amber-700">What you receive</p>
                            <ul class="grid list-none gap-1.5 p-0 m-0 md:grid-cols-2">
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Concrete pour photos &#x2B; cube test results</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Plumb and level inspection certificate</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Material delivery logs per floor</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Milestone-08 sign-off before MEP</span>
                                    </li>
                            </ul>
                        </div>
                        <p class="mt-4 wh-label-sm text-gray-500">
                            These are high-level specifications. For in-depth specs, refer to Annexure 2.
                            <a href="#service-lead-form" class="font-semibold text-amber-700 underline underline-offset-2 hover:text-amber-800">Contact us today</a>
                            for details.
                        </p>
                    </div>
                    <div class="mt-5 rounded-2xl border border-gray-200 bg-gray-50 p-5 md:p-6"
                         role="tabpanel"
                         id="milestone-panel-2"
                         aria-labelledby="milestone-tab-2"
                         data-milestone-panel="2"
                         hidden>
                        <div class="mb-4 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 border-b border-gray-200 pb-3.5">
                            <h3 class="wh-heading-md text-dark">Walls &amp; MEP</h3>
                            <p class="wh-label-sm font-semibold text-amber-700">Milestones 9&#x2013;12</p>
                        </div>

                        <ol class="grid list-none gap-3.5 p-0 m-0 md:grid-cols-2 md:gap-4">
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">09</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Plumbing</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">ISI-certified CPVC piping (hot/cold). Pressure tested before wall closure. Sewer lines.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">10</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Internal Painting</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Wall putty, primer, emulsion. Surface prep inspected before finish coat.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">11</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Electrical Wiring</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">ISI FR-LSH cables. Heavy-duty conduit piping. Pre-plaster.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">12</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Flooring</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Main/Bedroom: double-charged vitrified tiles. Common areas: granite. Balcony/Utility: anti-skid ceramic.</p>
                                    </div>
                                </li>
                        </ol>

                        <div class="mt-5 rounded-[0.85rem] border border-orange-200 bg-orange-50 px-4 py-4">
                            <p class="mb-2.5 wh-meta font-extrabold uppercase tracking-widest text-amber-700">What you receive</p>
                            <ul class="grid list-none gap-1.5 p-0 m-0 md:grid-cols-2">
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Plumbing pressure test certificate</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Electrical conduit inspection photo</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Flooring selection confirmation</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>2-year MEP warranty commences this stage</span>
                                    </li>
                            </ul>
                        </div>
                        <p class="mt-4 wh-label-sm text-gray-500">
                            These are high-level specifications. For in-depth specs, refer to Annexure 2.
                            <a href="#service-lead-form" class="font-semibold text-amber-700 underline underline-offset-2 hover:text-amber-800">Contact us today</a>
                            for details.
                        </p>
                    </div>
                    <div class="mt-5 rounded-2xl border border-gray-200 bg-gray-50 p-5 md:p-6"
                         role="tabpanel"
                         id="milestone-panel-3"
                         aria-labelledby="milestone-tab-3"
                         data-milestone-panel="3"
                         hidden>
                        <div class="mb-4 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 border-b border-gray-200 pb-3.5">
                            <h3 class="wh-heading-md text-dark">MEP Fixtures</h3>
                            <p class="wh-label-sm font-semibold text-amber-700">Milestones 13&#x2013;16</p>
                        </div>

                        <ol class="grid list-none gap-3.5 p-0 m-0 md:grid-cols-2 md:gap-4">
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">13</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Windows &amp; Ventilators</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">UPVC windows with mosquito mesh (3 tracks) and MS grills. 10% of slab area covered.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">14</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Doors</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Main: Teak frame (7&#x27;6&quot;x3&#x27;6&quot;, 5&quot;x3&quot; frame). Internal: Sal wood laminate flush (7x3).</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">15</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Sanitary Fixtures</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Master bath and other baths: package-based sanitary ware. Max 2 baths per 1,000 sft.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">16</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Kitchen</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Kitchen platform: granite. Sink: stainless steel. Branded faucet.</p>
                                    </div>
                                </li>
                        </ol>

                        <div class="mt-5 rounded-[0.85rem] border border-orange-200 bg-orange-50 px-4 py-4">
                            <p class="mb-2.5 wh-meta font-extrabold uppercase tracking-widest text-amber-700">What you receive</p>
                            <ul class="grid list-none gap-1.5 p-0 m-0 md:grid-cols-2">
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Fixture confirmation certificate</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Window weatherproofing inspection report</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Door hardware quality check document</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Flow &amp; pressure test for all sanitary</span>
                                    </li>
                            </ul>
                        </div>
                        <p class="mt-4 wh-label-sm text-gray-500">
                            These are high-level specifications. For in-depth specs, refer to Annexure 2.
                            <a href="#service-lead-form" class="font-semibold text-amber-700 underline underline-offset-2 hover:text-amber-800">Contact us today</a>
                            for details.
                        </p>
                    </div>
                    <div class="mt-5 rounded-2xl border border-gray-200 bg-gray-50 p-5 md:p-6"
                         role="tabpanel"
                         id="milestone-panel-4"
                         aria-labelledby="milestone-tab-4"
                         data-milestone-panel="4"
                         hidden>
                        <div class="mb-4 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 border-b border-gray-200 pb-3.5">
                            <h3 class="wh-heading-md text-dark">Finishing</h3>
                            <p class="wh-label-sm font-semibold text-amber-700">Milestones 17&#x2013;20</p>
                        </div>

                        <ol class="grid list-none gap-3.5 p-0 m-0 md:grid-cols-2 md:gap-4">
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">17</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Switchgears &amp; Electrical Fixtures</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Modular switches. Common areas provided with electrical points. 1 EV connection point included. UPS wiring provision included.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">18</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">External Flooring &amp; Terrace</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Terrace, parking, sit-out &#x2014; verified waterproofing. Parking: anti-skid tiles. Staircase railings: SS 304 grade.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">19</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Compound Wall</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Boundary wall, gate columns, cap and coping finish. Compound wall &amp; gate available as a separate add-on (SS/MS).</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">20</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Fabrication</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Staircase railings SS 304 grade. Shelves 10% of built-up area. OHT: 2000L 3-layer tank. All grills fitted and load tested.</p>
                                    </div>
                                </li>
                        </ol>

                        <div class="mt-5 rounded-[0.85rem] border border-orange-200 bg-orange-50 px-4 py-4">
                            <p class="mb-2.5 wh-meta font-extrabold uppercase tracking-widest text-amber-700">What you receive</p>
                            <ul class="grid list-none gap-1.5 p-0 m-0 md:grid-cols-2">
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Full load test report for electrical fixtures</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Terrace waterproofing test certificate</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>SS 304 railing inspection certificate</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Milestone-20 handover timeline confirmed</span>
                                    </li>
                            </ul>
                        </div>
                        <p class="mt-4 wh-label-sm text-gray-500">
                            These are high-level specifications. For in-depth specs, refer to Annexure 2.
                            <a href="#service-lead-form" class="font-semibold text-amber-700 underline underline-offset-2 hover:text-amber-800">Contact us today</a>
                            for details.
                        </p>
                    </div>
                    <div class="mt-5 rounded-2xl border border-gray-200 bg-gray-50 p-5 md:p-6"
                         role="tabpanel"
                         id="milestone-panel-5"
                         aria-labelledby="milestone-tab-5"
                         data-milestone-panel="5"
                         hidden>
                        <div class="mb-4 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 border-b border-gray-200 pb-3.5">
                            <h3 class="wh-heading-md text-dark">Handover</h3>
                            <p class="wh-label-sm font-semibold text-amber-700">Milestones 21&#x2013;24</p>
                        </div>

                        <ol class="grid list-none gap-3.5 p-0 m-0 md:grid-cols-2 md:gap-4">
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">21</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Rainwater Harvesting (RWH)</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">RWH included as per standards. Drainage network, connection to municipal line.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">22</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Final Inspection (250&#x2B; Points)</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Comprehensive quality walkthrough &#x2014; 250&#x2B; checkpoints across all categories. Punch list raised, resolved, and co-signed before keys.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">23</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Deep Cleaning</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Full post-construction deep clean of every room, bathroom, kitchen, and common area &#x2014; dust, debris, and construction residue cleared before keys.</p>
                                    </div>
                                </li>
                                <li class="flex items-start gap-3 rounded-[0.85rem] border border-gray-200 bg-white px-4 py-3.5">
                                    <span class="flex h-[1.85rem] w-[1.85rem] shrink-0 items-center justify-center rounded-full bg-orange-500 wh-meta font-extrabold text-white">24</span>
                                    <div>
                                        <p class="wh-label-sm font-bold text-dark">Formal Handover</p>
                                        <p class="mt-1 wh-label-sm text-gray-600 leading-normal">Final lockset, keys, all warranty documents, and product warranties. CCTV app login transferred. 10-year structural &#x2B; 2-year MEP warranty certificates.</p>
                                    </div>
                                </li>
                        </ol>

                        <div class="mt-5 rounded-[0.85rem] border border-orange-200 bg-orange-50 px-4 py-4">
                            <p class="mb-2.5 wh-meta font-extrabold uppercase tracking-widest text-amber-700">What you receive</p>
                            <ul class="grid list-none gap-1.5 p-0 m-0 md:grid-cols-2">
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>250-point inspection checklist &#x2014; co-signed</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Deep-clean completion confirmation</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>10-year structural &#x2B; 2-year MEP warranty certificates</span>
                                    </li>
                                    <li class="flex items-start gap-2 wh-label-sm text-gray-700 leading-snug">
                                        <span class="font-extrabold text-orange-500" aria-hidden="true">✓</span>
                                        <span>Product warranties handed over &#xB7; CCTV app login transferred</span>
                                    </li>
                            </ul>
                        </div>
                        <p class="mt-4 wh-label-sm text-gray-500">
                            These are high-level specifications. For in-depth specs, refer to Annexure 2.
                            <a href="#service-lead-form" class="font-semibold text-amber-700 underline underline-offset-2 hover:text-amber-800">Contact us today</a>
                            for details.
                        </p>
                    </div>
            </div>
        </div>
    </section>

            <section class="wh-section bg-white" id="problem-solution">
        <div class="wh-container">
            <div class="wh-section-head">
                <span class="wh-eyebrow-chip">The problem we solve</span>
                <h2 class="wh-heading-xl text-dark">Why most self built homes go wrong</h2>
                    <p class="wh-section-head__lede max-w-3xl">9 in 10 homeowners face at least one of these. WeHouse was built to eliminate every single one &#x2014; structurally, not just on paper.</p>
            </div>

            <div class="grid gap-5 md:grid-cols-2 md:gap-6">
                <div class="rounded-2xl border border-orange-200 bg-orange-50 p-5 md:p-6">
                    <h3 class="wh-heading-sm text-dark mb-4">The WeHouse difference</h3>
                    <ul class="flex flex-col gap-3 list-none m-0 p-0">
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white wh-meta font-extrabold" aria-hidden="true">✓</span>
                                <span>Price locked before work commencement.</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white wh-meta font-extrabold" aria-hidden="true">✓</span>
                                <span>Handover date in contract. We miss it &#x2192; we pay your rent.</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white wh-meta font-extrabold" aria-hidden="true">✓</span>
                                <span>ISI-certified cement &#x2B; Fe-550 TMT steel &#x2014; your choice brand, logged per batch.</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white wh-meta font-extrabold" aria-hidden="true">✓</span>
                                <span>Live CCTV, daily photos, material reports &#x2014; all on your phone 24/7.</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white wh-meta font-extrabold" aria-hidden="true">✓</span>
                                <span>One named PM, reachable 6 days/week. One number. Always.</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white wh-meta font-extrabold" aria-hidden="true">✓</span>
                                <span>24 signed milestone documents &#x2014; survey to handover.</span>
                            </li>
                    </ul>
                </div>
                <div class="rounded-2xl border border-gray-200 bg-gray-50 p-5 md:p-6">
                    <h3 class="wh-heading-sm text-dark mb-4">Typical contractor experience</h3>
                    <ul class="flex flex-col gap-3 list-none m-0 p-0">
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-red-100 text-red-700 wh-meta font-extrabold" aria-hidden="true">✗</span>
                                <span>Quoted &#x20B9;45L, billed &#x20B9;62L &#x2014; &quot;site conditions changed&quot;</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-red-100 text-red-700 wh-meta font-extrabold" aria-hidden="true">✗</span>
                                <span>Promised 12 months, took 22 &#x2014; nobody to call</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-red-100 text-red-700 wh-meta font-extrabold" aria-hidden="true">✗</span>
                                <span>Cement grade substituted &#x2014; you find out when cracks appear</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-red-100 text-red-700 wh-meta font-extrabold" aria-hidden="true">✗</span>
                                <span>Zero visibility &#x2014; no photos, no updates, no dashboard</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-red-100 text-red-700 wh-meta font-extrabold" aria-hidden="true">✗</span>
                                <span>5 sub-contractors, nobody owns the outcome</span>
                            </li>
                            <li class="flex items-start gap-2.5 wh-label-sm text-gray-700 leading-normal">
                                <span class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-red-100 text-red-700 wh-meta font-extrabold" aria-hidden="true">✗</span>
                                <span>No documentation &#x2014; only WhatsApp screenshots</span>
                            </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

        
    <section class="wh-section bg-white" id="package-teaser">
        <div class="wh-container">
            <div class="wh-section-head">
                <span class="wh-eyebrow-chip">Transparent pricing</span>
                <h2 class="wh-heading-xl text-dark">Fixed packages. No surprise add-ons.</h2>
                <p class="wh-section-head__lede max-w-3xl">See every tier, inclusion, and city rate on the Packages page &#x2014; then lock your scope.</p>
            </div>

            <div class="wh-card wh-card--soft mx-auto max-w-2xl p-8 text-center border-amber-200">
                <p class="mt-0 wh-meta font-extrabold uppercase tracking-widest text-amber-700">Starting from</p>
                <p class="mt-3 wh-price text-dark"><span class="text-amber-600">&#x20B9;1,749</span><span class="wh-price-unit text-gray-500">/sq.ft.</span></p>
                <p class="mt-3 wh-body-md text-gray-600">Fixed-scope packages from &#x20B9;1,749/sq.ft. in Hyderabad. Compare tiers, inclusions, and city pricing on the Packages page.</p>
                <div class="mt-6 flex flex-wrap justify-center gap-3">
                    <a href="/packages/hyderabad" class="wh-btn-primary wh-btn--lg inline-flex">Compare all packages &#x2192;</a>
                    <a href="#service-lead-form" class="wh-btn-tertiary">Calculate My Home Cost &#x2192;</a>
                </div>
            </div>
        </div>
    </section>


    <section class="wh-section wh-section-alt" id="service-portfolio">
    <div class="wh-container">
        <div class="wh-section-head">
                <span class="wh-eyebrow-chip">Our work</span>
                    <h2 class="wh-heading-xl text-dark">Homes WeHouse built</h2>
                    <p class="wh-section-head__lede">Real residential projects delivered with fixed pricing and milestone transparency.</p>
        </div>
        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                <figure class="wh-card wh-card--interactive overflow-hidden group">
                    <a href="/portfolio/TS-48" class="block">
                        <div class="aspect-[4/3] overflow-hidden bg-gray-100">
                            <img src="/uploads/portfolio/6960c92dcc474337891c13f4d2fb2d8d.jpeg"
                                 alt="jpg"
                                 class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                                 loading="lazy" />
                        </div>
                    </a>
                    <figcaption class="p-4">
                        <span class="text-xs font-semibold uppercase tracking-wide text-amber-600">Residential · Hyderabad</span>
                        <h3 class="mt-1 wh-heading-md text-dark">
                            <a href="/portfolio/TS-48" class="hover:text-amber-600 transition-colors">TS-48&#x2014;Bowenpally</a>
                        </h3>
                            <p class="mt-2 text-sm text-gray-600 italic line-clamp-2">"From planning to execution, the Wehouse team handled everything professionally. We are very pleased with the final result."</p>
                        <a href="/portfolio/TS-48" class="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-amber-600 hover:text-amber-700 transition-colors">
                            View Project Details →
                        </a>
                    </figcaption>
                </figure>
                <figure class="wh-card wh-card--interactive overflow-hidden group">
                    <a href="/portfolio/TS-143" class="block">
                        <div class="aspect-[4/3] overflow-hidden bg-gray-100">
                            <img src="/uploads/portfolio/48fe5fcff13e45eb8b3c786237f0d13d.jpeg"
                                 alt="jpg"
                                 class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                                 loading="lazy" />
                        </div>
                    </a>
                    <figcaption class="p-4">
                        <span class="text-xs font-semibold uppercase tracking-wide text-amber-600">Residential · Hyderabad</span>
                        <h3 class="mt-1 wh-heading-md text-dark">
                            <a href="/portfolio/TS-143" class="hover:text-amber-600 transition-colors">TS-143&#x2014;Patighanapur</a>
                        </h3>
                            <p class="mt-2 text-sm text-gray-600 italic line-clamp-2">"Our dream home has finally become a reality. We appreciate the entire WeHouse team for their hard work and commitment to quality."</p>
                        <a href="/portfolio/TS-143" class="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-amber-600 hover:text-amber-700 transition-colors">
                            View Project Details →
                        </a>
                    </figcaption>
                </figure>
                <figure class="wh-card wh-card--interactive overflow-hidden group">
                    <a href="/portfolio/TS-135" class="block">
                        <div class="aspect-[4/3] overflow-hidden bg-gray-100">
                            <img src="/uploads/portfolio/07d046582d8f4e14ad8ca1aae3f3b111.jpeg"
                                 alt="jpg"
                                 class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                                 loading="lazy" />
                        </div>
                    </a>
                    <figcaption class="p-4">
                        <span class="text-xs font-semibold uppercase tracking-wide text-amber-600">Residential · Hyderabad</span>
                        <h3 class="mt-1 wh-heading-md text-dark">
                            <a href="/portfolio/TS-135" class="hover:text-amber-600 transition-colors">TS-135&#x2014;Kukkatpallly</a>
                        </h3>
                            <p class="mt-2 text-sm text-gray-600 italic line-clamp-2">"&#x201C;The quality of construction and attention to detail have been impressive so far.&#x201D;"</p>
                        <a href="/portfolio/TS-135" class="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-amber-600 hover:text-amber-700 transition-colors">
                            View Project Details →
                        </a>
                    </figcaption>
                </figure>
                <figure class="wh-card wh-card--interactive overflow-hidden group">
                    <a href="/portfolio/TS-110" class="block">
                        <div class="aspect-[4/3] overflow-hidden bg-gray-100">
                            <img src="/uploads/portfolio/dd2cba7831a649b8a44b15d23a941bbf.jpeg"
                                 alt="jpg"
                                 class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                                 loading="lazy" />
                        </div>
                    </a>
                    <figcaption class="p-4">
                        <span class="text-xs font-semibold uppercase tracking-wide text-amber-600">Residential · Hyderabad</span>
                        <h3 class="mt-1 wh-heading-md text-dark">
                            <a href="/portfolio/TS-110" class="hover:text-amber-600 transition-colors">TS-110&#x2014;Nadergul</a>
                        </h3>
                            <p class="mt-2 text-sm text-gray-600 italic line-clamp-2">"The best part about working with WeHouse was the regular communication and project updates. It gave us confidence throughout the construction."</p>
                        <a href="/portfolio/TS-110" class="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-amber-600 hover:text-amber-700 transition-colors">
                            View Project Details →
                        </a>
                    </figcaption>
                </figure>
                <figure class="wh-card wh-card--interactive overflow-hidden group">
                    <a href="/portfolio/TS-93" class="block">
                        <div class="aspect-[4/3] overflow-hidden bg-gray-100">
                            <img src="/uploads/portfolio/a27a578ff8c24d058aebf680ddc3d547.jpeg"
                                 alt="jpg"
                                 class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                                 loading="lazy" />
                        </div>
                    </a>
                    <figcaption class="p-4">
                        <span class="text-xs font-semibold uppercase tracking-wide text-amber-600">Residential · Hyderabad</span>
                        <h3 class="mt-1 wh-heading-md text-dark">
                            <a href="/portfolio/TS-93" class="hover:text-amber-600 transition-colors">TS-93&#x2014;Bandlaguda Suncity</a>
                        </h3>
                            <p class="mt-2 text-sm text-gray-600 italic line-clamp-2">"We appreciate WeHouse for maintaining a systematic approach to our project.&#xD;&#xA;Their timely execution and regular updates kept us confident."</p>
                        <a href="/portfolio/TS-93" class="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-amber-600 hover:text-amber-700 transition-colors">
                            View Project Details →
                        </a>
                    </figcaption>
                </figure>
                <figure class="wh-card wh-card--interactive overflow-hidden group">
                    <a href="/portfolio/TS-92" class="block">
                        <div class="aspect-[4/3] overflow-hidden bg-gray-100">
                            <img src="/uploads/portfolio/52ed78b34fdd47e58913586af9281ced.jpeg"
                                 alt="jpg"
                                 class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                                 loading="lazy" />
                        </div>
                    </a>
                    <figcaption class="p-4">
                        <span class="text-xs font-semibold uppercase tracking-wide text-amber-600">Residential · Hyderabad</span>
                        <h3 class="mt-1 wh-heading-md text-dark">
                            <a href="/portfolio/TS-92" class="hover:text-amber-600 transition-colors">TS-92&#x2014;Siddarth Nagar</a>
                        </h3>
                            <p class="mt-2 text-sm text-gray-600 italic line-clamp-2">"&#x201C;The construction work is progressing well with WeHouse. We appreciate the team&#x2019;s dedication and professional approach.&#x201D;"</p>
                        <a href="/portfolio/TS-92" class="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-amber-600 hover:text-amber-700 transition-colors">
                            View Project Details →
                        </a>
                    </figcaption>
                </figure>
        </div>
        <div class="mt-8 text-center">
                <a href="/portfolio?type=Residential" class="wh-btn-tertiary">View all 500&#x2B; projects &#x2192;</a>
        </div>
    </div>
</section>

    <section class="wh-section bg-white" id="trust-signals">
    <div class="wh-container">
        <div class="wh-section-head">
                <span class="wh-eyebrow-chip">Why WeHouse</span>
                <h2 class="wh-heading-xl text-dark">India&#x27;s No.1 tech-powered home builder</h2>
                    <p class="wh-section-head__lede">Every point below is a contract clause, a real number, or a named brand &#x2014; not a marketing claim.</p>
        </div>
        <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">&#x20B9;0 Cost overruns</h3>
                    <p class="mt-2 wh-body-md text-gray-600">BOQ locked at signing. Change only if you request it.</p>
                </article>
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">Rent-back Delay guarantee</h3>
                    <p class="mt-2 wh-body-md text-gray-600">We miss your date &#x2192; we pay your monthly rent.</p>
                </article>
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">10 years Structural warranty</h3>
                    <p class="mt-2 wh-body-md text-gray-600">Foundation to roof, insured and warranted in writing.</p>
                </article>
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">2 years MEP warranty</h3>
                    <p class="mt-2 wh-body-md text-gray-600">ISI-certified wiring and CPVC plumbing &#x2014; all covered post-handover.</p>
                </article>
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">24/7 Live CCTV</h3>
                    <p class="mt-2 wh-body-md text-gray-600">Real feeds via WeHouse app. Accessible from anywhere.</p>
                </article>
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">250&#x2B; Quality checks</h3>
                    <p class="mt-2 wh-body-md text-gray-600">Engineer sign-off at each milestone before work progresses.</p>
                </article>
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">100% Vasthu compliant</h3>
                    <p class="mt-2 wh-body-md text-gray-600">Dedicated consultant reviews every floor plan.</p>
                </article>
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">ISI Certified materials</h3>
                    <p class="mt-2 wh-body-md text-gray-600">ISI cement and Fe-550 TMT steel &#x2014; logged per batch.</p>
                </article>
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">4 T&#x27;s Tech platform</h3>
                    <p class="mt-2 wh-body-md text-gray-600">Transparency &#xB7; Time &#xB7; Tracking &#xB7; Technology built in.</p>
                </article>
                <article class="wh-card p-5 text-center sm:text-left">
                    <div class="wh-icon-tile wh-icon-tile--lg mx-auto sm:mx-0 mb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3l8 4v6c0 5-3.5 7.5-8 8-4.5-.5-8-3-8-8V7l8-4z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark">Free Architecture &amp; drawings</h3>
                    <p class="mt-2 wh-body-md text-gray-600">All arch &amp; structural drawings included &#x2014; at no extra cost.</p>
                </article>
        </div>
            <div class="mt-8 text-center">
                <a href="/quality-assurance" class="wh-btn-tertiary">See our full quality assurance process &#x2192;</a>
            </div>
    </div>
</section>

<section class="wh-section wh-section-alt" id="service-testimonials">
    <div class="wh-container">
        <div class="wh-section-head">
                <span class="wh-eyebrow-chip">Client stories</span>
                <h2 class="wh-heading-xl text-dark">Real people. Real homes.</h2>
                    <p class="wh-section-head__lede">4.9&#x2605; on Google &#xB7; 500&#x2B; verified reviews</p>
        </div>
        <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <a href="https://www.youtube.com/@WeHouse" target="_blank" rel="noopener noreferrer" class="relative flex min-h-[280px] flex-col wh-photo-card group block overflow-hidden">
                    <div class="wh-photo-card__media absolute inset-0">
                        <img src="/images/testimonial-01.jpg" alt="Ramesh K. — G&#x2B;2 &#xB7; Kondapur, Hyderabad" class="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                    </div>
                    <div class="wh-photo-card__scrim"></div>
                    <span class="absolute left-1/2 top-1/2 z-10 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/95 text-amber-600 shadow-lg transition group-hover:scale-110" aria-hidden="true">
                        <svg viewBox="0 0 24 24" class="ml-1 h-6 w-6 fill-current"><path d="M8 5v14l11-7z"/></svg>
                    </span>
                    <div class="relative z-10 mt-auto flex min-h-[280px] flex-col justify-end p-5">
                        <span class="wh-chip wh-chip--ghost self-start">Delivered 3 weeks early</span>
                        <p class="mt-3 wh-label-sm leading-relaxed text-white/95 line-clamp-3">&quot;Not a single rupee over our contract price. In 25 years of dealing with builders, this has never happened. WeHouse is genuinely different.&quot;</p>
                        <p class="mt-3 wh-meta font-semibold text-white">Ramesh K. · G&#x2B;2 &#xB7; Kondapur, Hyderabad</p>
                    </div>
                </a>
                <a href="https://www.youtube.com/@WeHouse" target="_blank" rel="noopener noreferrer" class="relative flex min-h-[280px] flex-col wh-photo-card group block overflow-hidden">
                    <div class="wh-photo-card__media absolute inset-0">
                        <img src="/images/testimonial-02.jpg" alt="Suresh V. — G&#x2B;2 &#xB7; Chennai" class="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                    </div>
                    <div class="wh-photo-card__scrim"></div>
                    <span class="absolute left-1/2 top-1/2 z-10 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/95 text-amber-600 shadow-lg transition group-hover:scale-110" aria-hidden="true">
                        <svg viewBox="0 0 24 24" class="ml-1 h-6 w-6 fill-current"><path d="M8 5v14l11-7z"/></svg>
                    </span>
                    <div class="relative z-10 mt-auto flex min-h-[280px] flex-col justify-end p-5">
                        <span class="wh-chip wh-chip--ghost self-start">NRI client &#x2014; remote build</span>
                        <p class="mt-3 wh-label-sm leading-relaxed text-white/95 line-clamp-3">&quot;I was building from the UK. CCTV access and the daily WeHouse dashboard made me feel present on-site every single day.&quot;</p>
                        <p class="mt-3 wh-meta font-semibold text-white">Suresh V. · G&#x2B;2 &#xB7; Chennai</p>
                    </div>
                </a>
                <a href="https://www.youtube.com/@WeHouse" target="_blank" rel="noopener noreferrer" class="relative flex min-h-[280px] flex-col wh-photo-card group block overflow-hidden">
                    <div class="wh-photo-card__media absolute inset-0">
                        <img src="/images/testimonial-03.jpg" alt="Priya M. — G&#x2B;1 &#xB7; Gachibowli, Hyderabad" class="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                    </div>
                    <div class="wh-photo-card__scrim"></div>
                    <span class="absolute left-1/2 top-1/2 z-10 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/95 text-amber-600 shadow-lg transition group-hover:scale-110" aria-hidden="true">
                        <svg viewBox="0 0 24 24" class="ml-1 h-6 w-6 fill-current"><path d="M8 5v14l11-7z"/></svg>
                    </span>
                    <div class="relative z-10 mt-auto flex min-h-[280px] flex-col justify-end p-5">
                        <span class="wh-chip wh-chip--ghost self-start">On-time delivery</span>
                        <p class="mt-3 wh-label-sm leading-relaxed text-white/95 line-clamp-3">&quot;14 months start to handover &#x2014; and we moved in on the exact date written in the contract. First time in my life a builder kept their word.&quot;</p>
                        <p class="mt-3 wh-meta font-semibold text-white">Priya M. · G&#x2B;1 &#xB7; Gachibowli, Hyderabad</p>
                    </div>
                </a>
                <a href="https://www.youtube.com/@WeHouse" target="_blank" rel="noopener noreferrer" class="relative flex min-h-[280px] flex-col wh-photo-card group block overflow-hidden">
                    <div class="wh-photo-card__media absolute inset-0">
                        <img src="/images/testimonial-01.jpg" alt="Arun S. — Villa &#xB7; West Hyderabad" class="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                    </div>
                    <div class="wh-photo-card__scrim"></div>
                    <span class="absolute left-1/2 top-1/2 z-10 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/95 text-amber-600 shadow-lg transition group-hover:scale-110" aria-hidden="true">
                        <svg viewBox="0 0 24 24" class="ml-1 h-6 w-6 fill-current"><path d="M8 5v14l11-7z"/></svg>
                    </span>
                    <div class="relative z-10 mt-auto flex min-h-[280px] flex-col justify-end p-5">
                        <span class="wh-chip wh-chip--ghost self-start">Saved &#x20B9;9.5L</span>
                        <p class="mt-3 wh-label-sm leading-relaxed text-white/95 line-clamp-3">&quot;I got 6 quotes. WeHouse was the only one with a fixed price, signed timeline, and rent-back clause in the contract. That&#x27;s why I chose them.&quot;</p>
                        <p class="mt-3 wh-meta font-semibold text-white">Arun S. · Villa &#xB7; West Hyderabad</p>
                    </div>
                </a>
                <a href="https://www.youtube.com/@WeHouse" target="_blank" rel="noopener noreferrer" class="relative flex min-h-[280px] flex-col wh-photo-card group block overflow-hidden">
                    <div class="wh-photo-card__media absolute inset-0">
                        <img src="/images/testimonial-02.jpg" alt="Divya R. — Duplex &#xB7; Whitefield, Bangalore" class="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                    </div>
                    <div class="wh-photo-card__scrim"></div>
                    <span class="absolute left-1/2 top-1/2 z-10 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/95 text-amber-600 shadow-lg transition group-hover:scale-110" aria-hidden="true">
                        <svg viewBox="0 0 24 24" class="ml-1 h-6 w-6 fill-current"><path d="M8 5v14l11-7z"/></svg>
                    </span>
                    <div class="relative z-10 mt-auto flex min-h-[280px] flex-col justify-end p-5">
                        <span class="wh-chip wh-chip--ghost self-start">Full transparency</span>
                        <p class="mt-3 wh-label-sm leading-relaxed text-white/95 line-clamp-3">&quot;The e-monitoring app was extraordinary. I could see daily photos, material logs, and workforce reports &#x2014; without calling anyone.&quot;</p>
                        <p class="mt-3 wh-meta font-semibold text-white">Divya R. · Duplex &#xB7; Whitefield, Bangalore</p>
                    </div>
                </a>
        </div>
        <div class="mt-8 flex flex-wrap justify-center gap-3">
                <a href="/testimonials" class="wh-btn-tertiary">Read all reviews &#x2192;</a>
                <a href="https://g.page/r/wehouse/review" target="_blank" rel="noopener noreferrer" class="wh-btn-tertiary">View on Google →</a>
        </div>
    </div>
</section>


    <section class="wh-section wh-section--dark" id="service-lead-form">
    <div class="wh-container">
        <div class="grid gap-10 lg:grid-cols-2 lg:items-start">
            <div>
                <span class="wh-eyebrow-chip bg-orange-500/15 border-orange-500/35 text-orange-300">Get Started</span>
                <h2 class="wh-heading-xl text-white mt-3">Ready to build your home the right way?</h2>
                <p class="mt-4 wh-body-md text-gray-400">Tell us your city, plot size, and budget. Our team will send a personalised estimate &#x2014; fixed price, timeline locked. No pressure, no spam.</p>
                    <ul class="mt-6 space-y-2">
                            <li class="flex items-start gap-2 wh-label-sm text-amber-100/90">
                                <span class="font-bold text-amber-400" aria-hidden="true">✓</span>
                                <span>We respond within 2 business hours</span>
                            </li>
                            <li class="flex items-start gap-2 wh-label-sm text-amber-100/90">
                                <span class="font-bold text-amber-400" aria-hidden="true">✓</span>
                                <span>Architecture &amp; structural drawings included free</span>
                            </li>
                            <li class="flex items-start gap-2 wh-label-sm text-amber-100/90">
                                <span class="font-bold text-amber-400" aria-hidden="true">✓</span>
                                <span>&#x20B9;1,749/sft all-in &#xB7; No hidden additions ever</span>
                            </li>
                    </ul>
                <div class="mt-6 flex flex-wrap gap-x-4 gap-y-2 wh-label-sm text-gray-400">
                    <a href="tel:+916305504248" class="hover:text-white transition-colors">📞 &#x2B;91 63055 04248</a>
                    <a href="mailto:info@wehouse.in" class="hover:text-white transition-colors">✉️ info@wehouse.in</a>
                    <a href="https://wa.me/916305504248" target="_blank" rel="noopener noreferrer" class="hover:text-white transition-colors">💬 Chat on WhatsApp</a>
                </div>
            </div>
            <form class="flex flex-col gap-4 wh-card wh-form-card p-6 sm:p-8" novalidate data-service-lead data-service="Home Construction" data-privyr-api="/api/privyr-lead" data-thank-you-url="/thank-you" data-total-steps="3">
                <div class="flex items-center gap-1.5" aria-hidden="true">
                        <span class="h-2 w-2 rounded-full bg-gray-200 transition-[background-color,transform] duration-200 [&.is-active]:bg-amber-500 [&.is-current]:scale-125 [&.is-current]:bg-amber-600 is-active is-current" data-lead-step-dot="1"></span>
                            <span class="h-0.5 flex-1 rounded-full bg-gray-200"></span>
                        <span class="h-2 w-2 rounded-full bg-gray-200 transition-[background-color,transform] duration-200 [&.is-active]:bg-amber-500 [&.is-current]:scale-125 [&.is-current]:bg-amber-600" data-lead-step-dot="2"></span>
                            <span class="h-0.5 flex-1 rounded-full bg-gray-200"></span>
                        <span class="h-2 w-2 rounded-full bg-gray-200 transition-[background-color,transform] duration-200 [&.is-active]:bg-amber-500 [&.is-current]:scale-125 [&.is-current]:bg-amber-600" data-lead-step-dot="3"></span>
                </div>
                <p class="m-0 wh-meta font-semibold tracking-wide text-gray-500" data-lead-step-label>Step 1 of 3 — Contact details</p>

                    <div class="min-h-[12.5rem]" data-lead-step="1" data-lead-step-title="Contact details">
                        <div class="space-y-4">
                                <div>
                                    <label class="wh-field-label" for="lead-name">Your Name</label>
                                        <input id="lead-name" name="name" type="text" placeholder="E.g. Rohan Sharma" class="wh-field-input" data-lead-field data-lead-step="1" required data-lead-required />
                                </div>
                                <div>
                                    <label class="wh-field-label" for="lead-phone">Mobile Number</label>
                                        <input id="lead-phone" name="phone" type="tel" placeholder="Mobile number" class="wh-field-input" data-lead-field data-lead-step="1" required data-lead-required />
                                </div>
                                <div>
                                    <label class="wh-field-label" for="lead-email">Email</label>
                                        <input id="lead-email" name="email" type="email" placeholder="you@example.com" class="wh-field-input" data-lead-field data-lead-step="1" required data-lead-required />
                                </div>
                        </div>
                    </div>
                    <div class="min-h-[12.5rem] hidden" data-lead-step="2" data-lead-step-title="Project details">
                        <div class="space-y-4">
                                <div>
                                    <label class="wh-field-label" for="lead-city">Which city are you building in?</label>
                                        <select id="lead-city" name="city" class="wh-field-input" data-lead-field data-lead-step="2" required data-lead-required>
                                            <option value="">Select…</option>
                                                <option value="Hyderabad">Hyderabad</option>
                                                <option value="Amaravati">Amaravati</option>
                                                <option value="Ahmedabad">Ahmedabad</option>
                                                <option value="Chandigarh">Chandigarh</option>
                                                <option value="Chennai">Chennai</option>
                                                <option value="Bengaluru">Bengaluru</option>
                                                <option value="Jaipur">Jaipur</option>
                                                <option value="Pune">Pune</option>
                                                <option value="Other">Other</option>
                                        </select>
                                </div>
                                <div>
                                    <label class="wh-field-label" for="lead-sft">Plot Size (sq.ft.)</label>
                                        <input id="lead-sft" name="sft" type="text" placeholder="E.g. 2400" class="wh-field-input" data-lead-field data-lead-step="2" required data-lead-required />
                                </div>
                                <div>
                                    <label class="wh-field-label" for="lead-homeType">Home Type</label>
                                        <select id="lead-homeType" name="homeType" class="wh-field-input" data-lead-field data-lead-step="2" required data-lead-required>
                                            <option value="">Select…</option>
                                                <option value="Ground Floor">Ground Floor</option>
                                                <option value="G&#x2B;1">G&#x2B;1</option>
                                                <option value="G&#x2B;2">G&#x2B;2</option>
                                                <option value="Duplex">Duplex</option>
                                                <option value="Villa">Villa</option>
                                        </select>
                                </div>
                        </div>
                    </div>
                    <div class="min-h-[12.5rem] hidden" data-lead-step="3" data-lead-step-title="Almost done">
                        <div class="space-y-4">
                                <div>
                                    <label class="wh-field-label" for="lead-timeframe">When do you plan to start?</label>
                                        <select id="lead-timeframe" name="timeframe" class="wh-field-input" data-lead-field data-lead-step="3" required data-lead-required>
                                            <option value="">Select…</option>
                                                <option value="Within 3 months">Within 3 months</option>
                                                <option value="3&#x2013;6 months">3&#x2013;6 months</option>
                                                <option value="6&#x2013;12 months">6&#x2013;12 months</option>
                                                <option value="Just exploring">Just exploring</option>
                                        </select>
                                </div>
                                <div>
                                    <label class="wh-field-label" for="lead-requirements">Anything else we should know? (optional)</label>
                                        <textarea id="lead-requirements" name="requirements" rows="3" placeholder="Vastu, floors, budget range&#x2026;" class="wh-field-input" data-lead-field data-lead-step="3"  ></textarea>
                                </div>
                        </div>
                    </div>

                <input type="hidden" name="service" value="Home Construction" />
                <input type="hidden" name="leadType" value="service-page" />
                <input type="hidden" name="source" value="Service page — Home Construction" />

                <div class="mt-4 hidden" data-service-lead-otp>
                    <div id="service-lead-otp-card" class="rounded-xl border border-amber-200/80 bg-gradient-to-b from-amber-50/70 to-white p-3 space-y-2" data-lead-otp-block>
    <p id="service-lead-otp-phone-hint" class="wh-meta text-gray-600" data-otp-phone-hint></p>
    <div class="flex flex-wrap items-center gap-2">
        <button type="button" id="service-lead-send-otp" data-label="Send OTP" data-otp-send class="inline-flex items-center justify-center rounded-md border border-amber-500 bg-white px-3 py-1.5 wh-label-sm text-amber-800 hover:bg-amber-50">Send OTP</button>
        <span id="service-lead-otp-status" class="hidden" aria-live="polite" data-otp-status><span class="inline-flex items-center gap-1 wh-label-sm text-green-700"><span class="text-green-600" aria-hidden="true">✓</span> Mobile verified</span></span>
    </div>
    <div id="service-lead-otp-fields" class="space-y-1.5" data-otp-fields>
        <label for="service-lead-otp" class="wh-label-sm text-gray-700">Enter OTP from SMS</label>
        <div class="flex gap-2">
            <input id="service-lead-otp" name="otp" type="text" inputmode="numeric" maxlength="8" autocomplete="one-time-code" class="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="6-digit OTP" data-otp-input />
            <button type="button" id="service-lead-verify-otp" data-otp-verify class="shrink-0 rounded-lg bg-amber-600 px-3 py-2 wh-label-sm text-white hover:bg-amber-700">Verify</button>
        </div>
    </div>
</div>
<input type="text" name="hp_website" value="" tabindex="-1" autocomplete="off" class="sr-only absolute -left-[9999px] w-0 h-0 opacity-0" aria-hidden="true" />

                    <p class="mt-2 wh-label-sm text-amber-900/85 font-medium" data-service-otp-hint>Verify your mobile with OTP, then submit.</p>
                </div>

                <div class="flex items-center gap-2 pt-1">
                    <button type="button" class="wh-btn-secondary wh-btn--sm hidden" data-lead-back aria-label="Previous step">
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                        Back
                    </button>
                    <button type="button" class="wh-btn-primary wh-btn--sm flex-1" data-lead-next>
                        Next
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                    </button>
                    <button type="submit" class="wh-btn-primary wh-btn--block wh-btn--lg hidden flex-1" data-lead-submit disabled aria-disabled="true">Get My Free Cost Estimate &#x2192;</button>
                </div>
                <p class="hidden wh-label-sm text-red-600 text-center" data-otp-error></p>
                <p class="wh-meta text-gray-500 text-center">Architecture &amp; drawings included free &#xB7; No spam &#xB7; One call to clarify</p>
            </form>
        </div>
    </div>
</section>

    <section class="wh-section--compact bg-white relative overflow-hidden" aria-labelledby="service-faq-residential-construction-heading" id="service-faq">
    <div class="absolute inset-0 pointer-events-none bg-[radial-gradient(rgba(154,52,18,0.08)_1px,transparent_1px)] bg-[length:24px_24px] [mask-image:radial-gradient(ellipse_at_bottom_right,rgba(0,0,0,0.6),transparent_60%)]" aria-hidden="true"></div>
    <div class="wh-container relative">
        <div class="grid grid-cols-1 lg:grid-cols-[20rem_1fr] gap-8 lg:gap-14 items-start">
            <aside class="flex flex-col gap-5 lg:sticky lg:top-20">
                <div class="flex flex-col items-start">
                    <span class="wh-eyebrow-chip self-start">FAQ</span>
                        <h2 id="service-faq-residential-construction-heading" class="wh-heading-xl text-dark m-0">Questions people ask before calling us</h2>
                        <p class="text-[0.95rem] leading-[1.65] text-gray-600 max-w-[22rem] mt-3 mb-0">The 10 questions every prospect Googles at 11pm &#x2014; answered here, honestly.</p>
                            <div class="mt-5 space-y-2 text-sm text-gray-600">
                                <a href="mailto:info@wehouse.in" class="block hover:text-amber-700">✉️ Email — info@wehouse.in</a>
                                <a href="tel:+916305504248" class="block hover:text-amber-700">📞 &#x2B;91 63055 04248</a>
                                <a href="https://wa.me/916305504248" target="_blank" rel="noopener noreferrer" class="block hover:text-amber-700">💬 Chat on WhatsApp</a>
                            </div>
                </div>
            </aside>
            <div class="flex flex-col gap-2 min-w-0">
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-1">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">How much does home construction cost per sq ft in Hyderabad?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-1" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">WeHouse&#x27;s Standard Pro package is &#x20B9;2,149/sft in Hyderabad. This includes architecture &amp; structural drawings, soil test, full RCC structure, MEP (plumbing &#x2B; electrical), flooring, doors, windows, bathroom fittings, kitchen, painting, waterproofing, e-monitoring, and warranties. Stilt/parking is charged separately at &#x20B9;1,549/sft.</p>
                            </div>
                        </div>
                    </article>
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-2">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">Are architecture and structural drawings included?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-2" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">Yes. Architecture &amp; structural drawings are included FREE of cost in every WeHouse package. This includes basic 3D elevation, conceptual plans, working drawings, electrical drawings, plumbing drawings, detail elevation drawings, structural drawings, footing, column, plinth, slab, and staircase detailing.</p>
                            </div>
                        </div>
                    </article>
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-3">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">What brands of cement and steel does WeHouse use?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-3" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">WeHouse uses ISI-certified cement (43 grade surface, 53 grade core) and Fe-550 TMT standard steel from verified suppliers. Every delivery is digitally logged with brand, batch number, quantity, and date &#x2014; visible on your e-monitoring dashboard. Exact brand shortlists are confirmed in your package before signing.</p>
                            </div>
                        </div>
                    </article>
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-4">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">What is included in the bathroom scope?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-4" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">Master bathroom includes branded sanitary ware up to &#x20B9;30,000 (WC, basin mixer, 2-in-1 wall mixer, overhead shower, health faucet). Other bathrooms include fittings up to &#x20B9;20,000. Flooring: anti-skid ceramic &#x20B9;60/sft. Wall cladding: ceramic tiles &#x20B9;60/sft up to 8 feet. Plumbing: ISI-certified CPVC lines.</p>
                            </div>
                        </div>
                    </article>
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-5">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">How long does it take to build a G&#x2B;2 house?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-5" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">A typical G&#x2B;2 home (1,500&#x2013;2,000 sq.ft.) takes 14&#x2013;18 months from ground-breaking to handover. The timeline is locked in your contract at signing. If WeHouse misses the agreed handover date for any reason within our control, we reimburse your monthly rent for the period of delay &#x2014; written into every contract.</p>
                            </div>
                        </div>
                    </article>
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-6">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">What happens if WeHouse delays the project?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-6" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">If WeHouse misses the contractually agreed handover date, we reimburse your monthly rent for the period of delay. This is a written clause in every WeHouse contract &#x2014; not a verbal promise. Your handover date is locked before construction begins.</p>
                            </div>
                        </div>
                    </article>
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-7">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">Can I monitor construction from another city or abroad?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-7" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">Yes. Every WeHouse project has 24/7 CCTV cameras with live feeds on the WeHouse client app. You also receive daily photo and video reports, 24-milestone tracking, material delivery logs, cost tracker, and workforce attendance &#x2014; all from your phone, from anywhere in the world.</p>
                            </div>
                        </div>
                    </article>
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-8">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">What is not included in the package?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-8" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">Items NOT included: Municipal permissions (borne by landlord), bore well, motors, water connection during construction, rock cutting/blasting, sewage works, copper gas connection, solar heater, false ceiling, elevator/lift, compound wall &amp; gate (charged separately at &#x20B9;1,699/sft).</p>
                            </div>
                        </div>
                    </article>
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-9">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">What warranty does WeHouse provide after handover?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-9" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">WeHouse provides: (1) 10-year structural warranty on foundation, columns, beams, and slabs. (2) 2-year MEP warranty on all plumbing and electrical. Both are documented and signed as part of the formal handover packet. All brand product warranties are also transferred to you.</p>
                            </div>
                        </div>
                    </article>
                    <article class="group bg-white border border-gray-900/7 rounded-xl overflow-hidden shadow-sm transition-[border-color,background-color,box-shadow] hover:border-amber-500/30 data-[state=open]:border-amber-500/45 data-[state=open]:bg-[#fffaf3] data-[state=open]:shadow-lg data-[state=open]:shadow-amber-500/7 motion-reduce:transition-none" data-faq-item data-state="closed">
                        <button type="button" class="grid grid-cols-[1.75rem_1fr_auto] items-center gap-3 w-full text-left border-0 bg-transparent cursor-pointer p-3.5 md:p-4 focus-visible:outline-2 focus-visible:outline-amber-500 focus-visible:outline-offset-[-2px] rounded-xl" data-accordion-trigger aria-expanded="false" aria-controls="service-faq-residential-construction-answer-10">
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white transition-[background-color,transform] group-hover:bg-orange-600 group-data-[state=open]:bg-orange-600 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9.09 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="1.15" fill="currentColor" stroke="none" />
    </svg>
</span>

                            <span class="text-[0.9375rem] md:text-[0.975rem] font-semibold leading-snug text-gray-900 transition-colors group-data-[state=open]:text-orange-700">Does WeHouse build Vasthu-compliant homes?</span>
                            <span class="inline-flex size-7 shrink-0 items-center justify-center rounded-full border border-amber-500/35 text-amber-500 transition-[background-color,color,border-color] group-data-[state=open]:bg-amber-500 group-data-[state=open]:text-white group-data-[state=open]:border-amber-500 [&_svg]:size-[1.2rem]" aria-hidden="true">
    <svg class="group-data-[state=open]:hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
    </svg>
    <svg class="hidden group-data-[state=open]:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <path d="M5 12h14" />
    </svg>
</span>

                        </button>
                        <div class="wh-accordion-panel" id="service-faq-residential-construction-answer-10" role="region">
                            <div class="overflow-hidden min-h-0">
                                <p class="text-sm text-gray-600 leading-relaxed px-14 pb-3.5 max-sm:px-3.5 max-sm:pb-3 m-0">Yes. 100% Vasthu compliance is standard &#x2014; not an optional add-on. A dedicated Vasthu consultant reviews every floor plan before finalisation, covering plot orientation, door directions, kitchen, master bedroom, pooja room placement &#x2014; all aligned to Vasthu Shastra at the design stage.</p>
                            </div>
                        </div>
                    </article>
            </div>
        </div>
    </div>

    <script type="application/ld&#x2B;json">
    {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            { "@type": "Question", "name": "How much does home construction cost per sq ft in Hyderabad?", "acceptedAnswer": { "@type": "Answer", "text": "WeHouse\u0027s Standard Pro package is \u20B92,149/sft in Hyderabad. This includes architecture \u0026 structural drawings, soil test, full RCC structure, MEP (plumbing \u002B electrical), flooring, doors, windows, bathroom fittings, kitchen, painting, waterproofing, e-monitoring, and warranties. Stilt/parking is charged separately at \u20B91,549/sft." } },
            { "@type": "Question", "name": "Are architecture and structural drawings included?", "acceptedAnswer": { "@type": "Answer", "text": "Yes. Architecture \u0026 structural drawings are included FREE of cost in every WeHouse package. This includes basic 3D elevation, conceptual plans, working drawings, electrical drawings, plumbing drawings, detail elevation drawings, structural drawings, footing, column, plinth, slab, and staircase detailing." } },
            { "@type": "Question", "name": "What brands of cement and steel does WeHouse use?", "acceptedAnswer": { "@type": "Answer", "text": "WeHouse uses ISI-certified cement (43 grade surface, 53 grade core) and Fe-550 TMT standard steel from verified suppliers. Every delivery is digitally logged with brand, batch number, quantity, and date \u2014 visible on your e-monitoring dashboard. Exact brand shortlists are confirmed in your package before signing." } },
            { "@type": "Question", "name": "What is included in the bathroom scope?", "acceptedAnswer": { "@type": "Answer", "text": "Master bathroom includes branded sanitary ware up to \u20B930,000 (WC, basin mixer, 2-in-1 wall mixer, overhead shower, health faucet). Other bathrooms include fittings up to \u20B920,000. Flooring: anti-skid ceramic \u20B960/sft. Wall cladding: ceramic tiles \u20B960/sft up to 8 feet. Plumbing: ISI-certified CPVC lines." } },
            { "@type": "Question", "name": "How long does it take to build a G\u002B2 house?", "acceptedAnswer": { "@type": "Answer", "text": "A typical G\u002B2 home (1,500\u20132,000 sq.ft.) takes 14\u201318 months from ground-breaking to handover. The timeline is locked in your contract at signing. If WeHouse misses the agreed handover date for any reason within our control, we reimburse your monthly rent for the period of delay \u2014 written into every contract." } },
            { "@type": "Question", "name": "What happens if WeHouse delays the project?", "acceptedAnswer": { "@type": "Answer", "text": "If WeHouse misses the contractually agreed handover date, we reimburse your monthly rent for the period of delay. This is a written clause in every WeHouse contract \u2014 not a verbal promise. Your handover date is locked before construction begins." } },
            { "@type": "Question", "name": "Can I monitor construction from another city or abroad?", "acceptedAnswer": { "@type": "Answer", "text": "Yes. Every WeHouse project has 24/7 CCTV cameras with live feeds on the WeHouse client app. You also receive daily photo and video reports, 24-milestone tracking, material delivery logs, cost tracker, and workforce attendance \u2014 all from your phone, from anywhere in the world." } },
            { "@type": "Question", "name": "What is not included in the package?", "acceptedAnswer": { "@type": "Answer", "text": "Items NOT included: Municipal permissions (borne by landlord), bore well, motors, water connection during construction, rock cutting/blasting, sewage works, copper gas connection, solar heater, false ceiling, elevator/lift, compound wall \u0026 gate (charged separately at \u20B91,699/sft)." } },
            { "@type": "Question", "name": "What warranty does WeHouse provide after handover?", "acceptedAnswer": { "@type": "Answer", "text": "WeHouse provides: (1) 10-year structural warranty on foundation, columns, beams, and slabs. (2) 2-year MEP warranty on all plumbing and electrical. Both are documented and signed as part of the formal handover packet. All brand product warranties are also transferred to you." } },
            { "@type": "Question", "name": "Does WeHouse build Vasthu-compliant homes?", "acceptedAnswer": { "@type": "Answer", "text": "Yes. 100% Vasthu compliance is standard \u2014 not an optional add-on. A dedicated Vasthu consultant reviews every floor plan before finalisation, covering plot orientation, door directions, kitchen, master bedroom, pooja room placement \u2014 all aligned to Vasthu Shastra at the design stage." } }
        ]
    }
    </script>
</section>

</div>


    </main>

        <section class="bg-black text-gray-300 w-full">
            <div class="w-full border-t border-l border-white">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 bg-black [&>div]:border-r [&>div]:border-b [&>div]:border-white [&>div]:rounded-none [&>div]:p-6 [&>div]:min-h-[120px]">
                        <div>
                            <h3 class="wh-eyebrow text-amber-500 mb-2">Hyderabad</h3>
                            <p class="text-sm text-gray-400 break-words">252/A, Road No. 12, MLA Colony, Banjara Hills, Hyderabad, Telangana 500034</p>
                        </div>
                        <div>
                            <h3 class="wh-eyebrow text-amber-500 mb-2">Vijayawada</h3>
                            <p class="text-sm text-gray-400 break-words">FLAT NO : 405 5th floor, Anjanadri Musunuri Apartment, Ippatam Road, Mangalagiri, Vijayawada, Andhra Pradesh 522302</p>
                        </div>
                        <div>
                            <h3 class="wh-eyebrow text-amber-500 mb-2">Chennai</h3>
                            <p class="text-sm text-gray-400 break-words">3rd &amp; 4th Floor, 74, 5th Ave, V Block, Anna Nagar, Chennai, Greater Chennai, Tamil Nadu 600040</p>
                        </div>
                        <div>
                            <h3 class="wh-eyebrow text-amber-500 mb-2">Pune</h3>
                            <p class="text-sm text-gray-400 break-words">401, Trimurti Honey Gold, Ashok Nagar, Range Hill Rd, above Axis Bank, Shivajinagar, Pune, Maharashtra 411016</p>
                        </div>
                        <div>
                            <h3 class="wh-eyebrow text-amber-500 mb-2">Chandigarh</h3>
                            <p class="text-sm text-gray-400 break-words">199, 1st Floor, SCO No. 198, Shopping Plaza, 17C, Sector 17, Chandigarh, 160002</p>
                        </div>
                        <div>
                            <h3 class="wh-eyebrow text-amber-500 mb-2">Jaipur</h3>
                            <p class="text-sm text-gray-400 break-words">CCWVN (Plot No. 100, Vaishali Marg, Nemi Nagar Extension, Block A, Vaishali Nagar, Jaipur, Rajasthan)</p>
                        </div>
                </div>
            </div>
        </section>

    <footer id="site-footer" class="bg-black text-gray-400 relative overflow-hidden">
        <div class="wh-dark-dot-grid absolute inset-0 pointer-events-none" aria-hidden="true"></div>
        <!-- gradient blobs -->
        <div class="absolute -top-40 -right-40 w-[650px] h-[650px] bg-white/6 rounded-full blur-[120px] pointer-events-none"></div>
        <div class="absolute -bottom-40 -left-40 w-[600px] h-[600px] bg-white/5 rounded-full blur-[100px] pointer-events-none"></div>
        <!-- Lottie background on right - plays once when footer enters viewport -->
        <div class="absolute top-0 right-0 bottom-0 w-full max-w-md pointer-events-none overflow-hidden" aria-hidden="true">
            <dotlottie-player id="footer-lottie" src="/images/Prohouse Intro Animation.lottie" loop="false" mode="normal" class="absolute top-1/2 right-0 -translate-y-1/2 opacity-40 w-full min-w-0 max-w-full h-full min-h-[300px] sm:min-w-[400px]"></dotlottie-player>
            <!-- Gradient overlay to blend Lottie into footer bg -->
            <div class="absolute inset-0 bg-gradient-to-r from-black from-0% via-transparent via-70% to-transparent"></div>
        </div>
        <div class="relative z-10 mx-auto max-w-6xl xl:max-w-6xl 2xl:max-w-[90rem] px-4 py-12 sm:px-6 lg:px-8">
            <div class="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
                <div>
                    <img src="/images/wehouse-logo.svg" alt="WeHouse" class="h-10 w-auto brightness-0 invert" loading="lazy" decoding="async" />
                    <p class="mt-4 text-sm text-gray-500">Building excellence since day one. Quality construction for residential and commercial projects.</p>
                </div>
                <div>
                    <h3 class="wh-eyebrow text-amber-500">Quick Links</h3>
                    <ul class="mt-4 grid grid-cols-2 gap-x-4 gap-y-2">
                        <li><a class="text-gray-500 hover:text-white transition-colors" href="/">Home</a></li>
                        <li><a class="text-gray-500 hover:text-white transition-colors" href="/company/about-us">About</a></li>
                        <li><a class="text-gray-500 hover:text-white transition-colors" href="/service/residential-construction">Services</a></li>
                        <li><a class="text-gray-500 hover:text-white transition-colors" href="/portfolio">Projects</a></li>
                        <li><a class="text-gray-500 hover:text-white transition-colors" href="/packages">Packages</a></li>
                        <li><a class="text-gray-500 hover:text-white transition-colors" href="/quality-assurance">Quality Assurance</a></li>
                        <li><a class="text-gray-500 hover:text-white transition-colors" href="/testimonials">Testimonials</a></li>
                        <li><a class="text-gray-500 hover:text-white transition-colors" href="/faqs">FAQs</a></li>
                        <li><a href="/glossary" class="text-gray-500 hover:text-white transition-colors">Glossary</a></li>
                        <li><a class="text-gray-500 hover:text-white transition-colors" href="/contact-us">Contact</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="wh-eyebrow text-amber-500">Contact</h3>
                    <ul class="mt-4 space-y-2 text-sm text-gray-500">
                        <li>8-2-293/82/1/238, A/C, Road No 12, MLA Colony, Banjara Hills, Hyderabad, 500034</li>
                        <li>Ground Floor, Magna Lake View Apartments, Hitex Road, Hyderabad, 500084</li>
                        <li><a href="tel:+916305504248" class="hover:text-white transition-colors">+91 63055 04248</a></li>
                        <li><a href="mailto:info@wehouse.in" class="hover:text-white transition-colors">info@wehouse.in</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="wh-eyebrow text-amber-500">Follow Us</h3>
                    <div class="mt-4 flex gap-4">
                        <a href="https://www.facebook.com/wehouse.homeconstruction" class="text-gray-500 hover:text-white transition-colors" aria-label="Facebook"><svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></a>
                        <a href="https://www.linkedin.com/company/wehousehomeconstruction" class="text-gray-500 hover:text-white transition-colors" aria-label="LinkedIn"><svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg></a>
                        <a href="https://instagram.com/wehouse.in" class="text-gray-500 hover:text-white transition-colors" aria-label="Instagram"><svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg></a>
                        <a href="https://www.youtube.com/@WeHouse" class="text-gray-500 hover:text-white transition-colors" aria-label="YouTube" target="_blank" rel="noopener noreferrer"><svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg></a>
                        <a href="https://twitter.com/wehouse_in" class="text-gray-500 hover:text-white transition-colors" aria-label="Twitter" target="_blank" rel="noopener noreferrer"><svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a>
                    </div>
                </div>
            </div>
            <div class="mt-12 border-t border-white/10 pt-8 text-center text-xs text-gray-600 space-y-2">
                <p>Powered by <span class="text-gray-400 font-semibold tracking-wide">TIMESHELL</span></p>
                <p>&copy; 2026 WeHouse. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Lead popup modal -->
    <div id="lead-popup-overlay" class="fixed inset-0 z-[200] flex items-start sm:items-center justify-center p-4 overflow-y-auto opacity-0 pointer-events-none transition-opacity duration-300" aria-hidden="true">
        <div id="lead-popup-backdrop" class="fixed inset-0 z-[199] bg-black/50 backdrop-blur-xl" aria-hidden="true"></div>
        <div id="lead-popup" role="dialog" aria-modal="true" aria-labelledby="lead-popup-title" class="relative z-[200] w-full max-w-md max-h-[min(92dvh,calc(100vh-2rem))] my-auto sm:my-0 bg-white rounded-2xl shadow-2xl border border-amber-100 overflow-hidden transform scale-95 transition-transform duration-300 flex flex-col">
            <button type="button" id="lead-popup-close" class="absolute top-2.5 right-2.5 z-10 p-2 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors cursor-pointer" aria-label="Close">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
            <div class="p-5 sm:p-6 flex-1 min-h-0 overflow-y-auto">
                <h3 id="lead-popup-title" class="wh-heading-md text-dark mb-1.5 pr-8">Get Your Free Construction Plan</h3>
                <p id="lead-popup-lede" class="text-sm text-gray-600 mb-2">Share your details and our team will reach out within 24 hours with a personalised plan.</p>
                <p id="lead-popup-step-label" class="wh-label-sm text-amber-700 mb-3">Step 1 of 3 — Your details</p>
                <form id="lead-popup-form" class="space-y-3" novalidate data-privyr-api="/api/privyr-lead" data-thank-you-url="/thank-you">
                    <div class="lead-popup-step space-y-3" data-lead-popup-step="1">
                        <div>
                            <label for="lead-popup-name" class="wh-field-label">Full Name</label>
                            <input id="lead-popup-name" name="name" type="text" autocomplete="name" required class="wh-field-input" placeholder="E.g. Rohan Sharma" />
                        </div>
                        <div>
                            <label for="lead-popup-email" class="wh-field-label">Email</label>
                            <input id="lead-popup-email" name="email" type="email" autocomplete="email" required class="wh-field-input" placeholder="you@example.com" />
                        </div>
                        <div>
                            <label for="lead-popup-timeframe" class="wh-field-label">When are you planning the join?</label>
                            <select id="lead-popup-timeframe" name="timeframe" required class="wh-field-input">
                                <option value="">Select timeframe</option>
                                <option value="0-3">Within 3 months</option>
                                <option value="3-6">3–6 months</option>
                                <option value="6-12">6–12 months</option>
                                <option value="12&#x2B;">More than 12 months</option>
                            </select>
                        </div>
                    </div>
                    <div class="lead-popup-step hidden space-y-3" data-lead-popup-step="2">
                        <div>
                            <label for="lead-popup-phone" class="wh-field-label">Phone Number</label>
                            <input id="lead-popup-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" required class="wh-field-input" placeholder="Mobile number" />
                            <div id="lead-popup-otp-card" class="mt-2 rounded-lg border border-amber-200/80 bg-gradient-to-b from-amber-50/70 to-white p-2 space-y-2 shadow-sm">
                                <p id="lead-popup-otp-phone-hint" class="wh-meta text-gray-600 leading-tight"></p>
                                <div class="flex flex-wrap items-center gap-1.5">
                                    <button type="button" id="lead-popup-send-otp" data-label="Send OTP" class="inline-flex items-center justify-center rounded-md border border-amber-500 bg-white px-2.5 py-1.5 wh-label-sm text-amber-800 shadow-sm hover:bg-amber-50 transition-colors">Send OTP</button>
                                    <span id="lead-popup-otp-status" class="hidden" aria-live="polite"><span class="inline-flex items-center gap-0.5 wh-label-sm text-green-700"><span class="text-green-600" aria-hidden="true">✓</span> Verified</span></span>
                                </div>
                                <div id="lead-popup-otp-fields" class="space-y-1">
                                    <label for="lead-popup-otp" class="block wh-label-sm text-gray-700">SMS code</label>
                                    <div class="flex gap-1.5">
                                        <input id="lead-popup-otp" name="otp" type="text" inputmode="numeric" maxlength="8" autocomplete="one-time-code" class="flex-1 min-w-0 rounded-lg border border-gray-200 bg-white px-2.5 py-2 text-sm text-dark placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500" placeholder="6-digit OTP" />
                                        <button type="button" id="lead-popup-verify-otp" class="shrink-0 rounded-lg bg-amber-600 px-2.5 py-2 wh-label-sm text-white shadow-sm hover:bg-amber-700 transition-colors">Verify</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p id="lead-popup-step2-hint" class="wh-label-sm text-center text-amber-900/85 font-medium leading-tight">Verify your number to continue.</p>
                    </div>
                    <div class="lead-popup-step hidden space-y-3" data-lead-popup-step="3">
                        <div>
                            <label for="lead-popup-city" class="wh-field-label">City</label>
                            <select id="lead-popup-city" name="city" required class="wh-field-input">
                                <option value="">Select your city</option>
                                    <option value="Amaravati">Amaravati</option>
    <option value="Hyderabad">Hyderabad</option>
    <option value="Ahmedabad">Ahmedabad</option>
    <option value="Chandigarh">Chandigarh</option>
    <option value="Chennai">Chennai</option>
    <option value="Bengaluru">Bengaluru</option>
    <option value="Jaipur">Jaipur</option>
    <option value="Pune">Pune</option>
    <option value="Lucknow">Lucknow</option>
    <option value="Vijayawada">Vijayawada</option>
<option value="Other">Other</option>

                            </select>
                        </div>
                    </div>
                    <p id="lead-popup-submit-hint" class="hidden wh-label-sm text-center text-amber-900/85 font-medium leading-tight">Verify your mobile with OTP, then tap Get My Free Plan.</p>
                    <div id="lead-popup-actions" class="flex flex-wrap items-stretch gap-2 pt-1">
                        <button type="button" id="lead-popup-back" hidden class="inline-flex flex-1 min-w-[6rem] items-center justify-center gap-1 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-semibold text-gray-700 shadow-sm hover:bg-gray-50 transition-colors">Back</button>
                        <button type="button" id="lead-popup-next" class="inline-flex flex-1 min-w-[6rem] items-center justify-center gap-2 rounded-xl bg-amber-500 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-amber-500/30 hover:bg-amber-600 hover:shadow-lg hover:shadow-amber-500/35 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-amber-500 disabled:hover:shadow-md">Continue</button>
                        <button type="submit" id="lead-popup-submit" hidden class="inline-flex w-full min-w-0 flex-[1_1_100%] sm:flex-[2] items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-4 py-3 text-sm font-semibold text-white shadow-md shadow-amber-500/30 hover:shadow-lg hover:shadow-amber-500/40 hover:from-amber-400 hover:to-orange-400 transition-all duration-200">
                            <span>Get My Free Plan</span>
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                        </button>
                    </div>
                    <p id="lead-popup-error" class="hidden text-sm text-red-600 text-center"></p>
                    <p class="flex items-center justify-center gap-2 mt-1 px-3 py-2 rounded-xl bg-amber-500/6 border border-amber-500/14 wh-meta italic text-center text-stone-600">
                        <svg class="shrink-0 w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                        <span>We respect your privacy. No spam, ever.</span>
                    </p>
                </form>
                <div id="lead-popup-success" class="hidden text-center py-6">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-600 mb-4">
                        <svg class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark mb-2">Thank you!</h3>
                    <p class="text-sm text-gray-600 max-w-[280px] mx-auto mb-5">Our team will review your details and get back to you within 24 hours.</p>
                    <a href="https://wa.me/916305504248?text=Hi%20WeHouse%21%20I%20just%20submitted%20an%20enquiry%20about%20my%20dream%20home.%20Can%20we%20connect%3F" target="_blank" rel="noopener noreferrer" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl border border-green-500/35 bg-gradient-to-b from-green-500/12 to-green-500/6 text-green-700 font-semibold text-sm hover:bg-green-500/16 transition mx-auto">
                        <svg class="w-[1.125rem] h-[1.125rem]" viewBox="0 0 24 24" fill="#25D366" aria-hidden="true"><path d="M17.5 14.4c-.3-.1-1.7-.8-2-.9-.3-.1-.4-.2-.6.2s-.7.8-.8 1c-.2.2-.3.2-.6.1s-1.2-.4-2.3-1.4c-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6.1-.1.3-.4.4-.5.1-.2.2-.3.3-.5s.1-.4 0-.5c-.1-.1-.6-1.5-.9-2-.2-.5-.5-.5-.7-.5h-.5c-.2 0-.5.1-.7.4-.3.4-1 1-1 2.4s1 2.8 1.2 3 2.1 3.2 5.1 4.5c.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.7-.7 2-1.4.3-.7.3-1.2.2-1.4-.1-.1-.3-.2-.6-.4ZM12 2C6.5 2 2 6.5 2 12c0 1.8.5 3.6 1.4 5.1L2 22l4.9-1.4c1.5.8 3.3 1.3 5.1 1.3C17.5 22 22 17.5 22 12S17.5 2 12 2Z"/></svg>
                        Chat on WhatsApp
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Referral lead popup modal -->
    <div id="referral-popup-overlay" class="fixed inset-0 z-[200] flex items-start sm:items-center justify-center p-4 overflow-y-auto opacity-0 pointer-events-none transition-opacity duration-300" aria-hidden="true">
        <div id="referral-popup-backdrop" class="fixed inset-0 z-[199] bg-black/50 backdrop-blur-xl" aria-hidden="true"></div>
        <div id="referral-popup" role="dialog" aria-modal="true" aria-labelledby="referral-popup-title" class="relative z-[200] w-full max-w-md max-h-[min(92dvh,calc(100vh-2rem))] my-auto sm:my-0 bg-white rounded-2xl shadow-2xl border border-amber-100 overflow-hidden transform scale-95 transition-transform duration-300 flex flex-col">
            <div class="p-5 sm:p-6 flex-1 min-h-0 overflow-y-auto">
                <div class="flex items-start justify-between gap-4 mb-3">
                    <div class="flex items-center gap-2">
                        <span class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-amber-500 text-white text-sm font-bold">R</span>
                        <span class="wh-eyebrow text-amber-600">Refer & Earn</span>
                    </div>
                    <button type="button" id="referral-popup-close" class="shrink-0 p-2 -mt-1 -mr-1 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors cursor-pointer" aria-label="Close">
                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                    </button>
                </div>
                <h3 id="referral-popup-title" class="wh-heading-md text-dark mb-2">Refer a Friend, Earn Rewards</h3>
                <p class="text-sm text-gray-600 mb-3">Share your friend's details and our team will reach out to them. We'll keep you updated on the progress.</p>
                <p id="referral-popup-step-label" class="wh-label-sm text-amber-700 mb-4">Step 1 of 3 — Your details</p>
                <form id="referral-popup-form" class="space-y-4" novalidate data-privyr-api="/api/privyr-lead" data-thank-you-url="/thank-you">
                    <input type="hidden" name="leadType" value="referral" />
                    <div class="referral-popup-step space-y-4" data-referral-popup-step="1">
                        <div>
                            <label for="referral-your-name" class="wh-field-label">Your Name</label>
                            <input id="referral-your-name" name="name" type="text" autocomplete="name" required class="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm text-dark placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500" placeholder="E.g. Rohan Sharma" />
                        </div>
                        <div>
                            <label for="referral-your-email" class="wh-field-label">Your Email</label>
                            <input id="referral-your-email" name="email" type="email" autocomplete="email" required class="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm text-dark placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500" placeholder="you@example.com" />
                        </div>
                        <div>
                            <label for="referral-your-phone" class="wh-field-label">Your Phone</label>
                            <input id="referral-your-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" required class="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm text-dark placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500" placeholder="Your mobile number" />
                            <div id="referral-otp-card" class="mt-2 rounded-lg border border-amber-200/80 bg-gradient-to-b from-amber-50/70 to-white p-2 space-y-2 shadow-sm">
                                <p id="referral-otp-phone-hint" class="wh-meta text-gray-600 leading-tight"></p>
                                <div class="flex flex-wrap items-center gap-1.5">
                                    <button type="button" id="referral-send-otp" data-label="Send OTP" class="inline-flex items-center justify-center rounded-md border border-amber-500 bg-white px-2.5 py-1.5 wh-label-sm text-amber-800 shadow-sm hover:bg-amber-50 transition-colors">Send OTP</button>
                                    <span id="referral-otp-status" class="hidden" aria-live="polite"><span class="inline-flex items-center gap-0.5 wh-label-sm text-green-700"><span class="text-green-600" aria-hidden="true">✓</span> Verified</span></span>
                                </div>
                                <div id="referral-otp-fields" class="space-y-1">
                                    <label for="referral-otp" class="block wh-label-sm text-gray-700">SMS code</label>
                                    <div class="flex gap-1.5">
                                        <input id="referral-otp" type="text" inputmode="numeric" maxlength="8" autocomplete="one-time-code" class="flex-1 min-w-0 rounded-lg border border-gray-200 bg-white px-2.5 py-2 text-sm text-dark placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500" placeholder="6-digit OTP" />
                                        <button type="button" id="referral-verify-otp" class="shrink-0 rounded-lg bg-amber-600 px-2.5 py-2 wh-label-sm text-white shadow-sm hover:bg-amber-700 transition-colors">Verify</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p id="referral-step1-hint" class="wh-label-sm text-center text-amber-900/85 font-medium leading-tight">Verify your number to continue.</p>
                    </div>
                    <div class="referral-popup-step hidden space-y-4" data-referral-popup-step="2">
                        <div>
                            <label for="referral-friend-name" class="wh-field-label">Friend's Name</label>
                            <input id="referral-friend-name" name="referralName" type="text" required class="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm text-dark placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500" placeholder="E.g. Priya Verma" />
                        </div>
                        <div>
                            <label for="referral-friend-phone" class="wh-field-label">Friend's Phone</label>
                            <input id="referral-friend-phone" name="referralPhone" type="tel" inputmode="tel" required class="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm text-dark placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500" placeholder="Friend's mobile" />
                        </div>
                    </div>
                    <div class="referral-popup-step hidden space-y-4" data-referral-popup-step="3">
                        <div>
                            <label for="referral-city" class="wh-field-label">Friend's City (optional)</label>
                            <select id="referral-city" name="city" class="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm text-dark focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500">
                                <option value="">Select city</option>
                                    <option value="Amaravati">Amaravati</option>
    <option value="Hyderabad">Hyderabad</option>
    <option value="Ahmedabad">Ahmedabad</option>
    <option value="Chandigarh">Chandigarh</option>
    <option value="Chennai">Chennai</option>
    <option value="Bengaluru">Bengaluru</option>
    <option value="Jaipur">Jaipur</option>
    <option value="Pune">Pune</option>
    <option value="Lucknow">Lucknow</option>
    <option value="Vijayawada">Vijayawada</option>
<option value="Other">Other</option>

                            </select>
                        </div>
                    </div>
                    <p id="referral-submit-hint" class="hidden wh-label-sm text-center text-amber-900/85 font-medium leading-tight">Verify mobile above, then submit.</p>
                    <div id="referral-popup-actions" class="flex flex-wrap items-stretch gap-2 pt-1">
                        <button type="button" id="referral-popup-back" hidden class="inline-flex flex-1 min-w-[6rem] items-center justify-center gap-1 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-semibold text-gray-700 shadow-sm hover:bg-gray-50 transition-colors">Back</button>
                        <button type="button" id="referral-popup-next" class="inline-flex flex-1 min-w-[6rem] items-center justify-center gap-2 rounded-xl bg-amber-500 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-amber-500/30 hover:bg-amber-600 hover:shadow-lg hover:shadow-amber-500/35 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-amber-500 disabled:hover:shadow-md">Continue</button>
                        <button type="submit" id="referral-popup-submit" hidden class="inline-flex w-full min-w-0 flex-[1_1_100%] sm:flex-[2] items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-4 py-3 text-sm font-semibold text-white shadow-md shadow-amber-500/30 hover:shadow-lg hover:shadow-amber-500/40 hover:from-amber-400 hover:to-orange-400 transition-all duration-200">
                            <span>Submit Referral</span>
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                        </button>
                    </div>
                    <p id="referral-popup-error" class="hidden text-sm text-red-600 text-center"></p>
                    <p class="wh-meta leading-snug text-gray-400 text-center">We will contact your friend and keep you informed. No spam, ever.</p>
                </form>
                <div id="referral-popup-success" class="hidden text-center py-6">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-600 mb-4">
                        <svg class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    </div>
                    <h3 class="wh-heading-md text-dark mb-2">Thank You for the Referral!</h3>
                    <p class="text-sm text-gray-600">We’ll reach out to your friend shortly and update you on the next steps.</p>
                </div>
            </div>
        </div>
    </div>


    <script>
        window.WEHOUSE_CITY_SLUG_BY_NAME = {"Amaravati":"amaravati","Hyderabad":"hyderabad","Ahmedabad":"ahmedabad","Chandigarh":"chandigarh","Chennai":"chennai","Bengaluru":"bengaluru","Jaipur":"jaipur","Pune":"pune","Lucknow":"lucknow","Vijayawada":"vijayawada"};
    </script>
    <script src="/js/privyr-utm.js?v=ruQe_FgWB2KvO99uTBxuT6wQTm7-oHR6Aox_-e4HEoA"></script>
    <script src="/js/lead-otp.js?v=ec89XvFAUmrIuJJ99NqCq4JLB_4slS4d1DXX-Gmd0bs"></script>
    <script src="/js/site.js?v=DJx7yhG3gmLhjiUkJI8B8e3If2IoKONopqVR4bZj_CY" defer></script>
    <script>
        // Lazy load dotLottie player when first Lottie element is near viewport
        (function() {
            var lottieLoaded = false;
            function loadLottiePlayer() {
                if (lottieLoaded) return;
                lottieLoaded = true;
                var script = document.createElement('script');
                script.type = 'module';
                script.src = 'https://unpkg.com/@dotlottie/player-component@2.7.12/dist/dotlottie-player.mjs';
                document.head.appendChild(script);
            }
            var lottieElements = document.querySelectorAll('dotlottie-player');
            if (lottieElements.length > 0) {
                var lottieObserver = new IntersectionObserver(function(entries) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            loadLottiePlayer();
                            lottieObserver.disconnect();
                        }
                    });
                }, { rootMargin: '200px' });
                lottieElements.forEach(function(el) { lottieObserver.observe(el); });
            }
        })();

        // Footer Lottie play on reveal
        document.addEventListener("DOMContentLoaded", function() {
            var footer = document.getElementById("site-footer");
            var player = document.getElementById("footer-lottie");
            if (!footer || !player) return;
            var observer = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        if (player.stop) player.stop();
                        if (player.play) player.play();
                    }
                });
            }, { threshold: 0.2 });
            observer.observe(footer);
        });

        // Lazy load videos when they enter viewport
        (function() {
            var lazyVideos = document.querySelectorAll('video.lazy-video');
            if (lazyVideos.length === 0) return;
            
            var videoObserver = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        var video = entry.target;
                        // Load video src from data-src
                        if (video.dataset.src) {
                            video.src = video.dataset.src;
                        }
                        // Load source elements
                        var sources = video.querySelectorAll('source[data-src]');
                        sources.forEach(function(source) {
                            source.src = source.dataset.src;
                        });
                        if (sources.length > 0) {
                            video.load();
                        }
                        video.play();
                        videoObserver.unobserve(video);
                    }
                });
            }, { rootMargin: '200px', threshold: 0.1 });
            
            lazyVideos.forEach(function(video) {
                videoObserver.observe(video);
            });
        })();
    </script>
    
    <script src="/js/service-pages.js?v=fcmdKTeQYW9zMZP56LPZ0dG07Q4Ssvl_JCqtvPa-Dpo"></script>

    <script>
        document.addEventListener("click", function (event) {
            var target = event.target;
            if (!target || !target.closest) return;
            var telLink = target.closest('a[href*="tel:"]');
            if (!telLink || typeof gtag !== "function") return;
            gtag("event", "conversion", { send_to: "AW-767771084/pwLRCJje_9ACEMyDje4C" });
        });
    </script>
</body>
</html>
